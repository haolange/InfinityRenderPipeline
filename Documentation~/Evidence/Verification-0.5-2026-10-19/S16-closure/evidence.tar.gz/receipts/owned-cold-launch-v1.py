from pathlib import Path
import subprocess,json,time,os,re,sys
project='/Volumes/DataDisk/Projects/Unity/InfinityExample';cli='/Users/gushihao/.unity/bin/unity';root=Path(project+'/intermediate/verification-0.5/20261020-run02/S16');label=sys.argv[1]
assert re.fullmatch('[a-z0-9-]+',label)
s=json.loads(subprocess.run([cli,'status','--project-path',project,'--format','json'],capture_output=True,text=True).stdout);assert not s.get('data',{}).get('instances',[])
d=Path(project+'/Library/DataStore');pat=re.compile(r'(?:\._UDSData_[0-9]+\.bin|\._uds\.db|\._uds\.db-lock|\._uds\.lock)');assert not [f for f in d.iterdir() if pat.fullmatch(f.name)],'recorded sidecar checks needed'
p=subprocess.run([cli,'open',project,'--editor-path','/Users/gushihao/CGFiles/Engines/Unity/6000.6.0f1/Unity.app','--args','-openfile '+project+'/Assets/InfinityRPVerification_0_5_20261020_run02/S15/ShaderGraphs/GraphLighting.unity -logFile '+str(root/(label+'-Editor.log')),'--format','json'],capture_output=True,text=True);(root/(label+'-open.json')).write_text(p.stdout);print(p.stdout,flush=True);assert p.returncode==0;pid=json.loads(p.stdout)['data']['launchedPid'];(root/(label+'-pid.json')).write_text(json.dumps({'pid':pid,'project':project}));ready=False
while True:
 try:os.kill(pid,0)
 except ProcessLookupError:break
 if not ready:
  p=subprocess.run([cli,'status','--project-path',project,'--format','json'],capture_output=True,text=True)
  try:s=json.loads(p.stdout)
  except Exception:s={}
  if any(i.get('pid')==pid and i.get('state')=='ready' for i in s.get('data',{}).get('instances',[])):ready=True;(root/(label+'-ready.json')).write_text(p.stdout);print('OWNED READY '+str(pid),flush=True)
 time.sleep(2)
print('Owned Editor exited '+str(pid),flush=True)
