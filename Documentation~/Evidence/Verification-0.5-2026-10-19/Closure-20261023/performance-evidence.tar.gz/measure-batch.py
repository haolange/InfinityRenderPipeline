from pathlib import Path
import subprocess,json,time,sys
r=Path(__file__).parent

def call(file,method,args=[]):
 p=subprocess.run([sys.executable,str(r/'call-owned.py'),file,method,'perf-batch-call',json.dumps(args)],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 j=json.loads((r/'perf-batch-call.json').read_text());return j['data']['result']['result']
def wait(label):
 p=r/label/'measurement.json';deadline=time.monotonic()+170
 while not p.exists():
  if time.monotonic()>deadline:raise RuntimeError('No persisted measurement '+label)
  time.sleep(2)
 j=json.loads(p.read_text());assert j['phase']=='Completed',j.get('error');print(label,j['validSamples'],j['overall'],flush=True)
 return j
revision=sys.argv[1];prefix=sys.argv[2]
workloads=[('lights','AreaLights'),('shadows','Shadows'),('ssr','ScreenSpace'),('ssgi','ScreenSpace'),('fog','LocalLights'),('decal-replace','Decal')]
for kind,scene in workloads:
 label=prefix+'-'+kind+'-v3'
 if (r/label/'measurement.json').exists():
  wait(label);continue
 if kind!='lights' or prefix!='after':
  call('DiagnosticControl.cs','DiagnosticControl.Prepare',[scene]);time.sleep(2)
  call('PerformanceControl.cs','PerformanceControl.Configure',[kind,revision,1280,720]);time.sleep(2)
 call('PerformanceControl.cs','PerformanceControl.Begin',[label,900,120]);wait(label)
 print('RESTORE',call('PerformanceControl.cs','PerformanceControl.Restore'),flush=True)
 call('DiagnosticControl.cs','DiagnosticControl.Exit');time.sleep(2)
 call('DiagnosticControl.cs','DiagnosticControl.RestoreScene');time.sleep(.2)
print('BATCH COMPLETE',flush=True)
