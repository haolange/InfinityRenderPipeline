from pathlib import Path
import os,subprocess,json,hashlib,sys
r=Path(__file__).parent;repo=Path('/Volumes/DataDisk/Projects/Unity/InfinityExample/Packages/com.infinity.render-pipeline');pid=int((r/'owner-pid.txt').read_text())
try:os.kill(pid,0);raise RuntimeError('Owned Editor still alive')
except ProcessLookupError:pass
rows=json.loads((r/'performance-code-overlay.json').read_text());baseline=sys.argv[1]=='baseline'
for row in rows:
 p=repo/row['path'];present=True if baseline else row['baselinePresent'];assert p.exists()==present
 if present:assert hashlib.sha256(p.read_bytes()).hexdigest()==row['currentSha256' if baseline else 'baselineSha256']
for row in rows:
 p=repo/row['path'];present=row['baselinePresent'] if baseline else True
 if present:p.write_bytes(subprocess.check_output(['git','show',('1307adc:' if baseline else '602e649:')+row['path']],cwd=repo))
 else:p.unlink()
for row in rows:
 p=repo/row['path'];present=row['baselinePresent'] if baseline else True;assert p.exists()==present
 if present:assert hashlib.sha256(p.read_bytes()).hexdigest()==row['baselineSha256' if baseline else 'currentSha256']
print('Four exact source identities switched',sys.argv[1])
