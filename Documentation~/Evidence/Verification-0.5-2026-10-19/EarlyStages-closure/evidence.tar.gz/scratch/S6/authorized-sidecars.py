from pathlib import Path
import subprocess,hashlib,re,json,datetime,os
root=Path('/Volumes/DataDisk/Projects/Unity/InfinityExample');d=root/'Library/DataStore';base=root/'intermediate/verification-0.5/20261020-run02/S6'
assert not [], 'Original Example must be stopped'
pattern=re.compile(r'(?:\._UDSData_[0-9]+\.bin|\._uds\.db|\._uds\.db-lock|\._uds\.lock)')
allowed_hash='a2db81a38c4e74358e9910374df8821ffd8928fc6cc4638bda1ba87653b069bd'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4194304),b''):h.update(b)
 return h.hexdigest()
candidates=[f for f in d.iterdir() if pattern.fullmatch(f.name)]
for f in candidates:
 assert f.is_file() and not f.is_symlink() and f.stat().st_size==4096
 assert f.read_bytes()[:8]==bytes.fromhex('0005160700020000') and digest(f)==allowed_hash
 assert f.with_name(f.name[2:]).is_file(),'Missing real companion: '+f.name
if not candidates:
 print('No matching UDS sidecars; no isolation or real-file hashing needed',flush=True);raise SystemExit(0)
before={f.name:digest(f) for f in d.iterdir() if f.is_file() and not f.name.startswith('._')}
q=base/('authorized-isolation-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));q.mkdir()
(q/'intent.json').write_text(json.dumps({'names':[f.name for f in candidates],'before':before},indent=2)+'\n')
for f in candidates:
 target=q/(f.name+'.quarantined');os.rename(f,target);assert digest(target)==allowed_hash
assert {f.name:digest(f) for f in d.iterdir() if f.is_file() and not f.name.startswith('._')}==before
(q/'receipt.json').write_text(json.dumps({'names':[f.name for f in candidates],'bytes':4096*len(candidates),'real_root_files_hashes_unchanged':before,'rule':'User approved exact name patterns, 4096 bytes, magic and fixed SHA256; no real data moved/deleted'},indent=2)+'\n')
print('Authorized isolation',len(candidates),'sidecars;',q,flush=True)
