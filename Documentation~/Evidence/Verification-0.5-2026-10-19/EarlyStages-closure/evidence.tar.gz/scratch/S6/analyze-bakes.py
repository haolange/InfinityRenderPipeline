from pathlib import Path
import json,numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).parent
cases=['disk-baked','sun-zero','sun-two','spot-baked','spot-mixed']
report={};canvas=Image.new('RGB',(960,210*len(cases)),'#202020');draw=ImageDraw.Draw(canvas)
def load(case):
 r=P/'baked-normal'/(case+'-live');s=json.loads((r/'state.json').read_text());m=json.loads((r/'frames/capture.json').read_text());assert s['status']=='Restored' and not s['error'];assert s['producerDistinct']>=33 and s['producerFrame']-s['startFrame']>=32
 b={v['semantic']:np.fromfile(r/'frames'/v['file'],dtype='<f4' if v['format']=='R32_SFloat' else '<f2').reshape(v['height'],v['width'],-1).astype(float) for v in m['buffers']};return s,b
for ci,case in enumerate(cases):
 s,b=load(case);report[case]={'producer':s['producerFrame'],'distinctFrames':s['producerDistinct'],'gameSeconds':s['producerGameTime']-s['startGameTime'],'realSeconds':s['producerReal']-s['startReal'],'maps':s['frameState']['maps'],'receiverST':s['frameState']['receiverST'],'lightDump':s['frameState']['lightDump'],'bakingOutput':s['frameState']['bakingOutput']}
 for i,sem in enumerate(['BakedDiffuse','Lighting','DisplayColor']):
  a=np.flipud(b[sem][...,:3]);a=a/(1+a) if sem=='BakedDiffuse' else a;a=np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055);canvas.paste(Image.fromarray((np.clip(a,0,1)*255).astype('uint8')),(i*320,ci*210+30));draw.text((i*320+5,ci*210+8),case+' '+sem,fill='white')
canvas.save(P/'baked-frames-contact.png')
# Reconstruct receiver positions using this actual orthographic camera and sampled reversed-Z depth.
s,baked=load('spot-baked');_,mixed=load('spot-mixed');dep=baked['Depth'][...,0];y,x=np.mgrid[:180,:320];eye=50-dep*49.9;nx=2*(x+.5)/320-1;ny=2*(y+.5)/180-1
for sign in [1,-1]:
 wy=6+sign*ny*4*.759256542-eye*.650791466;mask=(dep>0)&(abs(wy)<.015);print('receiver reconstruction ySign',sign,'planePixels',int(mask.sum()))
 if mask.sum()>1000:break
wx=nx*4*(320/180);wz=-7+sign*ny*4*.650791466+eye*.759256542;r=np.sqrt(wx*wx+wz*wz)
plane=mask&(abs(wx)<2.7)&(abs(wz)<2.7);roi=plane&(r>.85)&(r<1.25)&(abs(wx)>.5)
L1=baked['Lighting'][...,:3].mean(-1);L2=mixed['Lighting'][...,:3].mean(-1);valid=roi&(L1>.001)&(L2>.001)
rat=L2[valid]/L1[valid];report['spot_intensity_comparison']={'orientationYSign':sign,'receiverPixels':int(plane.sum()),'roiPixels':int(valid.sum()),'mixedOverBakedMedian':float(np.median(rat)),'p05':float(np.percentile(rat,5)),'p95':float(np.percentile(rat,95)),'roi':'world receiver r .85..1.25m, |x|>.5, excluding caster shadow/plane boundary','notGeneralPerformance':True}
# Measure same receiver atlas profile: x direction, rows corresponding to z .6..9m.
profiles=[]
for row in range(86,95):
 widths=[]
 for case in ['sun-zero','sun-two']:
  a=np.fromfile(P/'bakes'/case/'map-0.rgba16f',dtype='<f2').reshape(256,256,4)[row,:,0].astype(float);a=a/np.median(a[10:40]);
  # Far right shadow edge, rising back to baseline.
  i=int(np.argmin(a[70:95]))+70;xs=np.arange(i,115);vals=a[xs]
  def cross(v):
   k=np.where(vals>=v)[0][0];return float(xs[k-1]+(v-vals[k-1])/(vals[k]-vals[k-1])) if k>0 else float(xs[0])
  widths.append((cross(.9)-cross(.1))*6/144)
 profiles.append({'row':row,'width0':widths[0],'width2':widths[1]})
report['sun_penumbra']={'method':'same atlas ST/geometry, right-edge 10-90 percent widths, native full-HDR half map, 6m receiver/144texels','rows':profiles,'median0Meters':float(np.median([r['width0'] for r in profiles])),'median2Meters':float(np.median([r['width2'] for r in profiles]))}
(P/'baked-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k in ['spot_intensity_comparison','sun_penumbra']},indent=2))
