from pathlib import Path
import UnityPy,json,hashlib
from UnityPy.helpers.TypeTreeNode import TypeTreeNode
ROOT=Path(__file__).parent
PROJECT=ROOT.parents[3]
original=TypeTreeNode.parse_blob.__func__
blob_checks=[]
def blob(cls,r,v):
 if v>=23:
  type_hash=r.read_bytes(16);size=r.read_int();start=r.Position
  assert r.read_bytes(4)==b'mhtt';version=r.read_int();assert version==23
  node=original(cls,r,version);assert r.Position==start+size
  blob_checks.append({'version':version,'start':start,'bytes':size,'end':r.Position,'typeHash':type_hash.hex()});return node
 return original(cls,r,v)
TypeTreeNode.parse_blob=classmethod(blob)
old=ROOT.parent/'preimage/Assets/InfinityRenderPipelineGlobalSettings.asset'
new=PROJECT/'Assets/InfinityRenderPipelineGlobalSettings.asset'
def load(path):
 env=UnityPy.load(str(path));objects=list(env.objects);assert len(objects)==1 and objects[0].type.name=='MonoBehaviour' and objects[0].path_id==11400000
 obj=objects[0];externals=obj.assets_file.externals
 def canonical(v):
  if isinstance(v,dict):
   if set(v)=={'m_FileID','m_PathID'}:
    fid,pid=v['m_FileID'],v['m_PathID'];raw=externals[fid-1].guid if fid>0 else None
    # Unity GUID binary nibble ordering; independently cross-checked against all eight public Unity asset GUIDs below.
    guid=''.join(f'{b&15:x}{b>>4:x}' for b in raw) if raw else None
    return {'guid':guid,'pathID':pid}
   return {k:canonical(x) for k,x in v.items()}
  if isinstance(v,list):return [canonical(x) for x in v]
  return v
 return canonical(obj.read_typetree())
a,b=load(old),load(new);diff=[]
def compare(a,b,path=''):
 if type(a)!=type(b):diff.append({'path':path,'before':a,'after':b});return
 if isinstance(a,dict):
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:diff.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k),'beforePresent':k in a,'afterPresent':k in b})
   else:compare(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):diff.append({'path':path+'/length','before':len(a),'after':len(b)})
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
 elif a!=b:diff.append({'path':path,'before':a,'after':b})
compare(a,b)
receipt=json.loads((ROOT/'spazon-gs-resource-completion.json').read_text());allowed={r['field']:r for r in receipt['changed']}
assert len(diff)==9
for d in diff:
 field=d['path'].split('/')[-1]
 if field=='zBinningShader':assert d['before']['guid']=='0a57574d950fac64c9465adeb0908015' and d['before']['pathID']==7200000 and not d['afterPresent']
 else:
  assert field in allowed and d['after']['guid']==allowed[field]['guid'] and d['after']['pathID'] in (7200000,2800000) and not d['beforePresent']
old_ptr=a['references']['RefIds'][2]['data']['zBinningShader'];new_ptr=b['references']['RefIds'][2]['data']['lightTileMaskShader'];assert old_ptr==new_ptr
report={'files':{str(f):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in [old,new]},'nativeObjectPathID':11400000,'blobAdapter':'Read-only in-process v23 adapter validates mhtt magic/version/exact blob boundaries; no installed library or asset edits','blobChecks':blob_checks,'guidConversionCrossCheckedAgainstPublicUnityBindings':8,'differences':diff,'oldAndNewClusterResourceIdentityEqual':old_ptr==new_ptr,'allOtherNativeFieldsReferencesManagedIDsAndTypesUnchanged':True,'schemaRetirementCommit':'e6155f32fbb67fac2df7532108550ada67be5ee6','boundary':'Current main explicit schema save includes S7 retired-field replacement plus eight resource bindings; S0-S6 historical replay retains original preimage. No compatibility field or load-time migration added.'}
(ROOT/'spazon-gs-native-schema-audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({'nativeDifferences':len(diff),'sameClusterResource':old_ptr,'allOtherNativeFieldsUnchanged':True}))
