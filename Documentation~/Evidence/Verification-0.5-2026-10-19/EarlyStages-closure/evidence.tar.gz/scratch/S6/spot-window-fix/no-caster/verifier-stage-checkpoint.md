# S6 independent verifier checkpoint — partial stage acceptance

This is an independent evidence checkpoint, not permission to mark S6 complete, commit the complete stage, or unlock S7. The implementing agent owns all Unity operations, source changes and final integration. This reviewer inspected source and existing evidence, reproduced numerical analysis without operating Unity, and wrote only the three requested small evidence files.

## Accepted subgates

- Historical S6 endpoint `834f41de69b241c585a5ef6fb07b852208b089f3` with the exact 75-file `historical-spot-identity.json` candidate was independently hash-checked 75/75. The Inspector adaptation retains the main mode-edit transaction in S6's Emission layout without later-stage foldouts or load-time migration.
- Actual historical targeted XML: angular GPU3/3, Shape23/23, Record9/9, Layout2/2, Lifecycle11/11, all Passed with zero skips. These cover the narrowed angular change, approved authored Disk carrier, Undo/Redo, color extraction and delegate-ownership contracts within their test scopes.
- Full historical run GUID `c07ad7e8-9afe-4404-86c5-1df9e8a837a1`, PID20790:1604 discovered/started/finished,1551Passed/0Failed/53Skipped,2reload/2resume. Stable callback identities exactly equal the checkpoint discovery set. Relative to prior1601 there are exactly3 added angular tests and no removed identities; all53 skip identities/verdicts are unchanged.
- Raw framework XML remains1571=1551Passed/0Failed/20Skipped. Its exact33 missing leaves are started/finished/checkpointed Skipped results with original checkpoint leaf XML equal to their callback-derived results after removing only the derived id/UniqueName additions. Raw and callback roots remain `Skipped:Ignored`; frameworkComplete=false and callbacksComplete=true are distinct, truthful statements. Parameterized duplicate fullnames were compared with multiplicity, not deduplicated. Progress is an aggregate count stream, not a substitute for per-stable-ID callback proof.
- Authored realtime Disk now enters native culling as Rectangle while retaining Additional Disk/radius0.85. Actual front/back records both have a valid native visibleLightIndex0; normal-frame front lighting rises and back lighting is suppressed. In38532 common world-plane interior pixels, back-minus-off maximum absolute RGB difference is0.0000152588; full-frame difference0.00747681 remains preserved. Different jitter phases prevent a whole-frame bit-identity claim.
- Baked Disk and Sun normal frames consume nonzero finite native lightmaps with baked lamps excluded from realtime records. All captures are tied to advancing production frames, not repeated frame1 callbacks. The original failed readback and frame1 controls remain failed historical evidence.
- Sun0deg/2deg matched-camera/atlas comparison: all9 measured shadow-edge rows widen; median10–90percent width0.0802809967m to0.1483922484m. This proves the source-angle effect in this fixture, not universal penumbra accuracy.
- Cone angular-window repair executes the shared production helper on a real GPU using packed records, transformed inputs, known transition values and Point/Pyramid/Box controls. The original linear-window GPU failure is retained; there is no assertion weakening or pi compensation.
- NoCaster Spot inner plateau, squared cosine transition and outer support agree between actual baked and realtime paths. The small transition errors refer specifically to0.8<r<2.1m; full sampled-radius errors including the inner knee are0.01001784(Baked) and0.00481878(Mixed). Near-axis normalization proves angular shape, not absolute scale.
- Absolute Spot intensity scale is independently supported without a fitted brightness coefficient. The actual decoded GBuffer albedo/normal and fixed Lambert formula predict realtime Lighting with median ratio0.99930877 and absolute relative errorP95=0.00144647. Native lightmap receiver-region integral/fixed theory=0.99807141. Normal Lighting Mixed/Baked integral ratio inside radius2.65m=1.00197687.
- NoCaster restoration receipt is Restored/errornull/stopped/outstanding0. FilmParity source/meta hashes were independently rechecked unchanged; the exact task bake asset folder and its meta were subsequently checked absent. This does not substitute for final stage-wide context/source closure after any further work.

## Preserved differences and limitations

The original uncompensated NoCaster world-grid intensity comparison remains median1.00246870 and absolute relative errorP95=0.08201891. It is not relabelled pixel equivalence or discarded. Native atlas centroid at texel(71.50999,71.52485), compared with the actual ST origin(72,72), gives an approximately half-texel world registration offset. Sampling the native map with unchanged original ST reproduces BakedDiffuse (relative errorP95 about0.00052). Using the independently measured centroid in a theoretical fixed-intensity comparison reduces P95 error to0.00318064; this is diagnostic and never applied to production UV or images. No specific engine, baker, or pipeline cause of that registration offset is established.

Cast-shadow images with the task caster differ. The discrepancy remains open for the later shadow/image gate; assigning follow-up to S12 is not proof of a S12 matrix root cause. Current-stage intensity acceptance is supported by separate absolute-scale measurements, not a newly invented8.2percent tolerance. Spatial samples and interpolated world-grid points are correlated, not independent trials or confidence intervals. This is not a performance assessment.

The shared punctual S6 shading branch does not consume Additional.specular separately. This fixture instead establishes Specular=0 through the actual material and GBuffer; it does not certify that independent weight contract.

## Remaining stage blockers

1. Actual native Inspector interaction/shape-handle evidence is still missing. Public setter, test-helper invocation, source review and a window bound to another project cannot stand in for it. No interaction with another Editor is authorized by this report.
2. Final immutable S6 main integration candidate, relevant current checks, source/context closure and deliberately retained evidence bundle still require final review. Historical completion does not make later main integration failures green.
3. Main's recorded later-stage failures and default/resource integration limitations remain separate final-HEAD blockers. This checkpoint does not import later-stage repairs, authorize a Player build, or unlock subsequent stages.

## Reproduction and identity

Run `python3 -B verifier-lambert-analysis.py` from any directory while its referenced original inputs are retained. It writes only `verifier-lambert-analysis.json` beside itself. The JSON lists every input it consumes with SHA256/bytes, the fixed physical formulas, actual material/capture checks, raw uncompensated residual, native-ST comparison and diagnostic centroid calculation. It uses numpy; it does not call Unity or change source, assets, UVs or original raw buffers. Original raw may be retired only after its remaining agreed consumers finish; reproduction then requires the exact listed inputs rather than a fabricated replacement or a permanent raw archive.

Evidence identities:

- `verifier-lambert-analysis.py` SHA256 `c2064295f8bb3396d851fbb4b832df489c93743572cefde629a2cb19785c2d33` (10810 bytes).
- `verifier-lambert-analysis.json` SHA256 `036d458b068b2c9758651f0fb71aa45e9d64f4e5c106fa8c7e3a6011c7480058` (9780 bytes).
- `S6/historical-spot-identity.json` SHA256 `c7256155cd9fc95b75c23ab8792a4e28f553326204739d06dc48f427ced55e87`.
- `S6/spot-historical-full/run.json` SHA256 `0949e9eac47a1a48c721ca1cbcd53dbb544d89ddd13bc7b5e80ab07137454867`.
- `S6/spot-historical-full/results.xml` SHA256 `393d47bc5b6d05d6f02bf8bbd2fd6c95a954ac6ce313c4208d2b8535c7dc3134`.
- `S6/spot-historical-full/callback-results.xml` SHA256 `4c6ebfab537224ffdd29d2ae2368f3c786eab802e2e2c1dad23760af8ee9d824`.
- `S6/spot-historical-full/reload-checkpoint.json` SHA256 `8884dbbfc51c06a446759be7479217c4e932bd1f310030b1c327687cebce07c5`.
- `S6/spot-historical-full/progress.jsonl` SHA256 `72ec69af6e8152e2957fcf446088797833d84e5df688281f5f4cdb2a562d8b41`.
