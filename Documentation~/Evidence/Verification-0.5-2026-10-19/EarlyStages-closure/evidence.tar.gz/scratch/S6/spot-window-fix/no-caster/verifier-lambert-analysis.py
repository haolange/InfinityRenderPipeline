#!/usr/bin/env python3
"""Reproduce the S6 fixed-strength analysis. Reads existing evidence only.
Run: python3 -B verifier-lambert-analysis.py
Writes only verifier-lambert-analysis.json beside this script. Requires numpy.
No production UV, image, Unity object, source asset, or original raw is changed.
"""
from pathlib import Path
import hashlib
import json
import numpy as np

ROOT = Path(__file__).resolve().parent
INPUTS = {}

def read(path):
    path = Path(path)
    raw = path.read_bytes()
    INPUTS[str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)] = {
        'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    return raw

def js(path):
    return json.loads(read(path))

def matrix(d):
    return np.array([[d[f'e{i}{j}'] for j in range(4)] for i in range(4)])

def quantiles(v):
    return dict(zip(['p05', 'median', 'p95'], map(float, np.quantile(v, [.05, .5, .95]))))

def ideal_irradiance(x, z):
    # Fixed scene: source (0,4,0), intensity30, range30, full inner20/outer60 degrees.
    # Native baked diffuse is irradiance/pi, subsequently multiplied by runtime albedo.
    distance = np.sqrt(x*x + z*z + 16.0)
    angular = np.clip((4.0/distance - np.cos(np.pi/6)) /
                      (np.cos(np.pi/18) - np.cos(np.pi/6)), 0, 1)**2
    return (30.0/np.pi) * (1.0-(distance/30.0)**4)**2 * 4.0/distance**3 * angular

def bilinear(a, x, y):
    ix, iy = np.floor(x).astype(int), np.floor(y).astype(int)
    assert np.all(ix >= 0) and np.all(iy >= 0)
    assert np.all(ix+1 < a.shape[1]) and np.all(iy+1 < a.shape[0])
    u, v = x-ix, y-iy
    return (a[iy,ix]*(1-u)*(1-v) + a[iy,ix+1]*u*(1-v) +
            a[iy+1,ix]*(1-u)*v + a[iy+1,ix+1]*u*v)

cases = {}
for name in ['spot-baked', 'spot-mixed']:
    directory = ROOT/'baked-normal'/(name+'-live')
    state = js(directory/'state.json')
    cap = js(directory/'frames/capture.json')
    bake = js(ROOT/'bakes'/name/'run.json')
    imports = js(ROOT/'bakes'/name/'import-analysis-configuration.json')
    assert state['status'] == 'Restored' and state['error'] is None
    assert state['producerDistinct'] >= 33
    assert state['producerFrame']-state['startFrame'] >= 32
    assert state['producerGameTime'] > state['startGameTime']
    assert cap['status'] == 'Completed' and cap['outstanding'] == 0 and cap['retired'] == 7
    assert not cap['error'] and not cap['persistenceError'] and len(cap['frames']) == 1
    assert bake['status'] == 'Completed' and bake['outstanding'] == 0 and not bake['error']
    arrays = {}
    for b in cap['buffers']:
        raw = read(directory/'frames'/b['file'])
        assert len(raw) == b['bytes'] and b['producerFrame'] == state['producerFrame']
        assert b['submitted'] and b['retired'] and b['readbackTerminal'] and not b['error']
        dtype = {'R32_SFloat':'<f4', 'R8G8B8A8_UNorm':'u1', 'R16G16B16A16_SFloat':'<f2'}[b['format']]
        a = np.frombuffer(raw, dtype=dtype).reshape(180,320,-1).astype(float)
        assert np.isfinite(a).all()
        arrays[b['semantic']] = a/255 if dtype == 'u1' else a
    assert set(arrays) == {'Lighting','BakedDiffuse','Depth','DisplayColor','GBufferA','GBufferB','GBufferC'}
    f = cap['frames'][0]
    yy, xx = np.mgrid[:180,:320]
    clip = np.stack([(xx+.5)/320*2-1, (yy+.5)/180*2-1,
                     arrays['Depth'][...,0], np.ones((180,320))], -1)
    w = clip @ matrix(f['inverseJitteredViewProjection']).T
    world = w[...,:3]/w[...,3:]
    cases[name] = {'state':state, 'frame':f, 'arrays':arrays, 'world':world,
                   'bake':bake, 'imports':imports}

baked, mixed = cases['spot-baked'], cases['spot-mixed']
assert baked['state']['frameState']['materialJson'] == mixed['state']['frameState']['materialJson']
ln = [json.loads(cases[k]['state']['frameState']['light'])['Light'] for k in cases]
assert [k for k in ln[0] if ln[0][k] != ln[1][k]] == ['m_Lightmapping']
assert ln[0]['m_Lightmapping'] == 2 and ln[1]['m_Lightmapping'] == 1
assert baked['frame']['jitteredViewProjection'] == mixed['frame']['jitteredViewProjection']
assert np.array_equal(baked['arrays']['Depth'], mixed['arrays']['Depth'])
world = baked['world']
radius = np.hypot(world[...,0], world[...,2])
roi = (abs(world[...,1]) < .02) & (radius > .1) & (radius < 1.8)
for case in cases.values():
    a = case['arrays']
    assert np.all(a['GBufferB'][roi,3] == 0)
    assert np.all(a['GBufferA'][roi,2] == 1) and np.all(a['GBufferA'][roi,3] == 0)
    assert np.all((np.rint(a['GBufferC'][roi,0]*255).astype(int) & 64) != 0)
    assert np.array_equal(np.unique(a['GBufferA'][roi],axis=0), [[55/255,128/255,1,0]])
# Both stored chroma and every interior neighbor's chroma are128/255: decoded RGB=55/255.
albedo = 55/255
normal = mixed['arrays']['GBufferB'][...,:3]*2-1
normal /= np.maximum(np.linalg.norm(normal,axis=2,keepdims=True),1e-20)
L = np.array([0.,4.,0.])-world
distance = np.linalg.norm(L,axis=2)
L /= distance[...,None]
normal_factor = np.sum(normal*L,axis=2)/(4/distance)
absolute_lambert = ideal_irradiance(world[...,0],world[...,2])*normal_factor*albedo
actual_mixed = mixed['arrays']['Lighting'][...,:3].mean(-1)
absolute_ratio = actual_mixed[roi]/absolute_lambert[roi]

native_raw = read(ROOT/'bakes/spot-baked/map-0.rgba16f')
assert len(native_raw) == 256*256*8
native = np.frombuffer(native_raw,'<f2').reshape(256,256,4).astype(float)
assert np.isfinite(native).all()
# Receiver atlas: six world metres occupy144 texels; ST offsets are half a native texel.
st = baked['state']['frameState']['receiverST']
assert st == [.5625,.5625,.001953125,.001953125]
texels_per_metre = st[0]*256/6
origin_index = (st[0]*.5+st[2])*256-.5
assert texels_per_metre == 24 and origin_index == 72
lm = native[...,:3].mean(-1)
receiver = lm[:144,:144]
y,x = np.mgrid[:144,:144]
cx, cz = float((receiver*x).sum()/receiver.sum()), float((receiver*y).sum()/receiver.sum())
offset_x, offset_z = (cx-origin_index)/24, (cz-origin_index)/24
X,Z = world[...,0][roi], world[...,2][roi]
observed = baked['arrays']['BakedDiffuse'][...,:3].mean(-1)[roi]
sampled = bilinear(lm, origin_index+24*X, origin_index+24*Z)
sampling_ratio = sampled/observed
prediction = ideal_irradiance(X,Z)
centroid_prediction = ideal_irradiance(X-offset_x,Z-offset_z)
half_texel_prediction = ideal_irradiance(X+.5/24,Z+.5/24)
original_error = observed/prediction-1
sum_rows = []
for bound in [1.8,2.65,2.8]:
    mask = (abs(world[...,1])<.02)&(radius<bound)
    sum_rows.append({'radiusMeters':bound,'pixels':int(mask.sum()),
        'mixedOverBakedLightingSum':float(mixed['arrays']['Lighting'][...,:3][mask].sum()/
                                        baked['arrays']['Lighting'][...,:3][mask].sum())})
quadrants=[]
for label,mask in [('--',(X<-.2)&(Z<-.2)),('++',(X>.2)&(Z>.2)),
                   ('-+',(X<-.2)&(Z>.2)),('+-',(X>.2)&(Z<-.2))]:
    quadrants.append({'xzSigns':label,'pixels':int(mask.sum()),
                      'bakedOverUnshiftedTheoryMedian':float(np.median(observed[mask]/prediction[mask]))})
original = js(ROOT/'fixed-spot-analysis.json')['comparison']
read(ROOT.parents[1]/'historical-spot-identity.json')
output = {
 'schema':'S6-independent-lambert-v1',
 'verdict':'Spot absolute intensity scale supported; spatial registration and shadow equivalence remain separate/open',
 'formulas':{'sourcePosition':[0,4,0],'intensity':30,'range':30,'fullInnerDegrees':20,'fullOuterDegrees':60,
  'receiverPlane':'y=0, normal+Y','materialSpecular':0,'materialReflectance':0,'materialRoughness':1,
  'decodedAlbedoRGB':[albedo]*3,
  'angular':'saturate((4/d-cos30)/(cos10-cos30))^2',
  'idealBakedIrradiance':'(30/pi)*(1-(d/30)^4)^2*(4/d^3)*angular, d=sqrt(16+x^2+z^2)',
  'realtimeLambert':'idealBakedIrradiance*decodedAlbedo*(decodedNormalDotL/(4/d))',
  'fittedBrightnessScale':None,'productionUVModified':False},
 'normalCapture':{k:{'producerFrame':v['state']['producerFrame'],'distinctFrames':v['state']['producerDistinct'],
  'producerGameTime':v['state']['producerGameTime'],'status':'Restored','buffers':7,'outstanding':0}
  for k,v in cases.items()},
 'pixelRoi':{'definition':'actual pixel centres, abs(worldY)<.02, .1<radius<1.8','pixels':int(roi.sum())},
 'gbuffer':{'albedoStoredRGBA':[55/255,128/255,1,0],
  'normalStoredRGB':np.unique(mixed['arrays']['GBufferB'][roi,:3],axis=0).tolist(),
  'explanation':'Constant gray chroma and material channels in both cases; no checkerboard color variation in this ROI'},
 'mixedAbsoluteLambert':{'ratio':quantiles(absolute_ratio),
  'absRelativeErrorP95':float(np.quantile(abs(absolute_ratio-1),.95))},
 'nativeAtlas':{'size':[256,256],'receiverTexels':[144,144],'receiverST':st,
  'originTexelIndex':[origin_index,origin_index],'centroidTexelIndex':[cx,cz],
  'centroidWorldOffsetMeters':[offset_x,offset_z],'halfTexelMeters':.5/24,
  'sumOverFixedTheoryAtOriginalOrigin':float(receiver.sum()/ideal_irradiance((x-72)/24,(y-72)/24).sum()),
  'sumOverFixedTheoryAtHalfTexelOrigin':float(receiver.sum()/ideal_irradiance((x-71.5)/24,(y-71.5)/24).sum())},
 'bakedDiffuseMatchesOriginalST':{'sampledMapOverBakedDiffuseRatio':quantiles(sampling_ratio),
  'absRelativeErrorP95':float(np.quantile(abs(sampling_ratio-1),.95))},
 'spatialDiagnosticOnly':{
  'originalBakedOverTheoryRatio':quantiles(observed/prediction),
  'centroidPositionFixedIntensityRatio':quantiles(observed/centroid_prediction),
  'centroidPositionAbsRelativeErrorP95':float(np.quantile(abs(observed/centroid_prediction-1),.95)),
  'halfTexelPositionAbsRelativeErrorP95':float(np.quantile(abs(observed/half_texel_prediction-1),.95)),
  'unshiftedRelativeErrorCorrelationWithXPlusZ':float(np.corrcoef(original_error,X+Z)[0,1]),
  'quadrants':quadrants,'notAnOutputCorrection':True},
 'normalLightingSums':sum_rows,
 'originalUncompensatedWorldGridComparisonRetained':original,
 'limitations':['No production UV or raw image was changed. Diagnostic theoretical translation is not a rendering fix.',
  'The observed native lightmap-grid registration difference is not attributed to a specific engine or pipeline root cause.',
  'Spatial samples are correlated, not independent trials or confidence intervals.',
  'Original world-grid P95 residual remains approximately8.2%; no post-hoc tolerance is introduced.',
  'Cast-shadow equivalence, native Inspector interaction and final stage restoration/closure are separate gates.'],
 'inputs':INPUTS,
 'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
}
out=ROOT/'verifier-lambert-analysis.json'
out.write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'output':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
 'mixedRatio':output['mixedAbsoluteLambert']['ratio'],'nativeIntegral':output['nativeAtlas']['sumOverFixedTheoryAtOriginalOrigin'],
 'centroid':output['nativeAtlas']['centroidTexelIndex']}))
