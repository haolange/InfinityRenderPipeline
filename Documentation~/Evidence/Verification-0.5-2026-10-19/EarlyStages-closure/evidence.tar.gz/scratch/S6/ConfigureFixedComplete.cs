using System;using System.IO;using System.Linq;using System.Reflection;using UnityEditor;using UnityEngine;using UnityEngine.Rendering;using InfinityTech.Rendering.Pipeline;
public static class S6ConfigureMain {
 const string Root="/Volumes/DataDisk/Projects/Unity/InfinityExample/intermediate/verification-0.5/20261020-run02/S6";
 public static object Run(){if(EditorApplication.isCompiling||EditorApplication.isPlaying)throw new Exception("Idle required");
 var gs=InfinityRenderPipelineGlobalSettings.Require();var original=EditorJsonUtility.ToJson(gs,true);if(!File.Exists(Root+"/fixed-gs-original.json"))File.WriteAllText(Root+"/fixed-gs-original.json",original);
 GraphicsSettings.TryGetRenderPipelineSettings(out InfinityRenderPipelineRuntimeShaders shaders);GraphicsSettings.TryGetRenderPipelineSettings(out InfinityRenderPipelineRuntimeTextures textures);GraphicsSettings.TryGetRenderPipelineSettings(out InfinityRenderPipelineRuntimeMaterials materials);GraphicsSettings.TryGetRenderPipelineSettings(out InfinityDefaultVolumeProfileSettings defaults);
 var changes=new System.Collections.Generic.List<string>();
 foreach(object container in new object[]{shaders,textures,materials}) foreach(var f in container.GetType().GetFields(BindingFlags.Public|BindingFlags.Instance)){
 if(!typeof(UnityEngine.Object).IsAssignableFrom(f.FieldType)||(UnityEngine.Object)f.GetValue(container))continue;
 var attr=f.CustomAttributes.SingleOrDefault(a=>a.AttributeType.Name=="ResourcePathAttribute");if(attr==null)continue;
 var rel=(string)attr.ConstructorArguments[0].Value;var path=InfinityRenderPipelineRuntimeShaders.PackagePath+"/"+rel;var value=AssetDatabase.LoadAssetAtPath(path,f.FieldType);if(!value)throw new Exception("Missing "+path);f.SetValue(container,value);changes.Add(f.Name+"="+path);
 }
 var profile=DefaultVolumeProfileFactory.CreateInMemory();profile.name="S6 Historical verification memory defaults";profile.hideFlags=HideFlags.HideAndDontSave;foreach(var c in profile.components)c.hideFlags=HideFlags.HideAndDontSave;defaults.volumeProfile=profile;changes.Add("defaultProfile="+profile.name);
 File.WriteAllText(Root+"/fixed-memory-config-complete.json",Newtonsoft.Json.JsonConvert.SerializeObject(new {pid=System.Diagnostics.Process.GetCurrentProcess().Id,changes,originalDirty=EditorUtility.IsDirty(gs),configured=EditorJsonUtility.ToJson(gs)},Newtonsoft.Json.Formatting.Indented));
 return new {changes,requiredDefaults=DefaultVolumeProfileFactory.HasRequiredDefaultComponents(profile),saved=false};}
}
