using System;using System.IO;using System.Collections.Generic;using UnityEngine;using UnityEditor;using UnityEngine.Rendering;using UnityEngine.Experimental.GlobalIllumination;using InfinityTech.Rendering.LightPipeline;
public static class S6RadianceProbe {public static object Run(){
 var go=new GameObject("S6 owned radiance oracle");var light=go.AddComponent<Light>();light.type=UnityEngine.LightType.Point;light.intensity=1;light.lightmapBakeType=LightmapBakeType.Mixed;
 bool linear=GraphicsSettings.lightsUseLinearIntensity,temperature=GraphicsSettings.lightsUseColorTemperature;var samples=new List<object>();
 try{GraphicsSettings.lightsUseLinearIntensity=true;GraphicsSettings.lightsUseColorTemperature=true;
 foreach(var color in new[]{Color.white,new Color(.5f,.5f,.5f),new Color(.2f,.5f,.8f)})foreach(bool cct in new[]{false,true}){
 light.color=color;light.useColorTemperature=cct;light.colorTemperature=3500;
 var gi=new PointLight();LightmapperUtils.Extract(light,ref gi);
 var rgb=gi.color;FLightRecordPack.TryPack(light,null,LightShapeUtility.FromUnityLight(light),0,Vector3.zero,out var record);
 samples.Add(new {input=new[]{color.r,color.g,color.b},cct,temperature=light.colorTemperature,realtime=new[]{record.radiance.x,record.radiance.y,record.radiance.z},bake=new[]{rgb.red*rgb.intensity,rgb.green*rgb.intensity,rgb.blue*rgb.intensity},bakeIntensity=rgb.intensity});}
 var result=new {pid=System.Diagnostics.Process.GetCurrentProcess().Id,unity=Application.unityVersion,linearIntensity=true,temperatureSupported=true,samples};File.WriteAllText("/Volumes/DataDisk/Projects/Unity/InfinityExample/intermediate/verification-0.5/20261020-run02/S6/radiance-original-main.json",Newtonsoft.Json.JsonConvert.SerializeObject(result,Newtonsoft.Json.Formatting.Indented));return result;
 }finally{UnityEngine.Object.DestroyImmediate(go);GraphicsSettings.lightsUseLinearIntensity=linear;GraphicsSettings.lightsUseColorTemperature=temperature;}}}
