from pathlib import Path
import runpy,json,hashlib,UnityPy
ROOT=Path(__file__).parent
adapter=runpy.run_path(str(ROOT/'audit-spazon-gs-native.py'))
old=ROOT/'spazon-profile-preimage/InfinityDefaultVolumeProfile.asset'
new=Path('/Volumes/DataDisk/Projects/Unity/InfinityExample/Packages/com.infinity.render-pipeline/Runtime/Resources/InfinityDefaultVolumeProfile.asset')
def load(path):
 env=UnityPy.load(str(path));items={}
 for obj in env.objects:
  assert obj.type.name=='MonoBehaviour'
  ext=obj.assets_file.externals
  def canonical(v):
   if isinstance(v,dict):
    if set(v)=={'m_FileID','m_PathID'}:
     fid,pid=v['m_FileID'],v['m_PathID'];raw=ext[fid-1].guid if fid>0 else None
     return {'guid':''.join(f'{b&15:x}{b>>4:x}' for b in raw) if raw else None,'pathID':pid}
    return {k:canonical(x) for k,x in v.items()}
   if isinstance(v,list):return [canonical(x) for x in v]
   return v
  items[str(obj.path_id)]=canonical(obj.read_typetree())
 return items
a,b=load(old),load(new);assert len(a)==15 and len(b)==16 and set(a)<=set(b);added=list(set(b)-set(a));assert len(added)==1;newobj=b[added[0]];assert newobj['m_Name']=='ProbeVolumesOptions';diff=[]
def compare(a,b,path):
 if type(a)!=type(b):diff.append({'path':path,'before':a,'after':b});return
 if isinstance(a,dict):
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:diff.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k),'beforePresent':k in a,'afterPresent':k in b})
   else:compare(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):diff.append({'path':path+'/length','before':len(a),'after':len(b)})
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
 elif a!=b:diff.append({'path':path,'before':a,'after':b})
for key in a:compare(a[key],b[key],key)
removed={'BilateralColorWeight','BilateralDepthWeight','BilateralNormalWeight','BilateralSample','NumRays','SpatialRadius','SpatialSample'}
newfields={'quality','SunNumSteps','HalfResolution','LinearRoughness','LinearSteps','MirrorRoughness','ResolveRadius','ResolveSamples','SpatialPasses'}
for d in diff:
 parts=d['path'].split('/');key,field=parts[0],parts[1]
 if key=='11400000':assert d['path']=='11400000/components/length' and d['before']==14 and d['after']==15;continue
 name=a[key]['m_Name'];d['component']=name
 if d['after'] is None:
  assert name in ['ScreenSpaceReflection','ScreenSpaceIndirectDiffuse'] and field in removed and d['before']['m_OverrideState']==0
 else:
  assert not d['beforePresent'] and field in newfields and d['after']['m_OverrideState']==0
assert b['11400000']['components'][:-1]==a['11400000']['components'];assert b['11400000']['components'][-1]=={'guid':None,'pathID':int(added[0])}
report={'files':{str(f):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in [old,new]},'oldObjectCount':15,'newObjectCount':16,'addedAPVLocalID':added[0],'originalObjectIDsPreserved':True,'originalComponentReferenceOrderPreserved':True,'nativeDifferences':diff,'addedObject':newobj,'allOtherNativeFieldsAndReferenceIdentitiesUnchanged':True,'removedLegacyParametersAllOverrideFalse':True,'addedCurrentParametersAllOverrideFalse':True,'boundary':'Current main explicit packaged-profile schema save materializes current S4/S5/S10/S14 parameters, retires listed legacy SSR/SSGI parameters and appends APV. It is not a byte-only APV append. S6 fix excludes this later-stage asset candidate; preserve original for early replay.'}
(ROOT/'spazon-profile-native-schema-audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({'differences':len(diff),'newObjectID':added[0],'retiredParameters':sum(d.get('after') is None for d in diff),'allOtherNativeFieldsUnchanged':True}))
