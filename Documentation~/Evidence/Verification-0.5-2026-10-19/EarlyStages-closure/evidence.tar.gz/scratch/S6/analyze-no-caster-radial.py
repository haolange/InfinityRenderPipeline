import runpy,json,numpy as np
from pathlib import Path
D=runpy.run_path(str(Path(__file__).with_name('analyze-no-caster.py')))
P=D['P']; mat=D['matrix']; sample=D['sample']; result={}; rr=np.linspace(0,2.65,107); theta=np.linspace(0,2*np.pi,73)[:-1];x=rr[:,None]*np.cos(theta);z=rr[:,None]*np.sin(theta);points=np.stack([x,np.zeros_like(x),z,np.ones_like(x)],-1)
distance=np.sqrt(16+rr*rr);geom=(1-(distance/30)**4)**2/distance**2*4/distance
expected=np.clip((4/distance-np.cos(np.deg2rad(30)))/(np.cos(np.deg2rad(10))-np.cos(np.deg2rad(30))),0,1)**2
for name,(a,m) in D['data'].items():
 clip=points@mat(m['frames'][0]['jitteredViewProjection']).T;ndc=clip[...,:3]/clip[...,3:];px=(ndc[...,0]*.5+.5)*320-.5;py=(ndc[...,1]*.5+.5)*180-.5
 assert np.all((px>=0)&(px<319)&(py>=0)&(py<179))
 values=sample(a['Lighting'][...,:3],px,py).mean(-1);radial=np.median(values,axis=1);corrected=radial/geom;normalized=corrected/np.median(corrected[rr<.4]);inner=rr<.6;transition=(rr>.8)&(rr<2.1);outside=rr>2.45
 result[name]={'radius':rr.tolist(),'angularNormalizedMedian':normalized.tolist(),'expectedSquaredCosineWindow':expected.tolist(),'innerPlateauMin':float(normalized[inner].min()),'innerPlateauMax':float(normalized[inner].max()),'transitionAbsErrorMedian':float(np.median(abs(normalized[transition]-expected[transition]))),'transitionAbsErrorMax':float(np.max(abs(normalized[transition]-expected[transition]))),'outsideMaxNormalized':float(normalized[outside].max()),'innerRadiusExpected':float(4*np.tan(np.deg2rad(10))),'outerRadiusExpected':float(4*np.tan(np.deg2rad(30))),'method':'72 angles per radius; each actual jittered VP, inverse-square/range/cosine geometry factored then near-axis normalization; correlated spatial samples, not independent trials'}
(P/'radial-analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:{a:b for a,b in v.items() if not isinstance(b,list)} for k,v in result.items()},indent=2))
