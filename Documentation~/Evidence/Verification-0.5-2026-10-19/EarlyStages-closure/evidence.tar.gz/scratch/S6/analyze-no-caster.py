from pathlib import Path
import json,numpy as np,hashlib
from PIL import Image,ImageDraw
P=Path(__file__).parent/'spot-window-fix'/'no-caster';report={};data={};canvas=Image.new('RGB',(960,420),'#222');draw=ImageDraw.Draw(canvas)
def matrix(d):return np.array([[d['e'+str(i)+str(j)] for j in range(4)] for i in range(4)])
def sample(a,x,y):
 x=np.clip(x,0,a.shape[1]-1.00001);y=np.clip(y,0,a.shape[0]-1.00001);i=np.floor(x).astype(int);j=np.floor(y).astype(int);fx=x-i;fy=y-j;return a[j,i]*(1-fx)[...,None]*(1-fy)[...,None]+a[j,i+1]*fx[...,None]*(1-fy)[...,None]+a[j+1,i]*(1-fx)[...,None]*fy[...,None]+a[j+1,i+1]*fx[...,None]*fy[...,None]
for ci,name in enumerate(['spot-baked','spot-mixed']):
 root=P/'baked-normal'/(name+'-live');s=json.loads((root/'state.json').read_text());m=json.loads((root/'frames/capture.json').read_text());assert s['status']=='Restored' and not s['error'];assert s['producerDistinct']>=33;assert s['frameState']['specularLevel']==0 and s['frameState']['roughness']==1 and s['frameState']['reflectance']==0
 a={}
 for b in m['buffers']:
  dtype='<f4' if b['format']=='R32_SFloat' else 'u1' if b['format']=='R8G8B8A8_UNorm' else '<f2';v=np.fromfile(root/'frames'/b['file'],dtype=dtype).reshape(180,320,-1).astype(float);a[b['semantic']]=v/255 if dtype=='u1' else v;assert np.isfinite(v).all()
 yy,xx=np.mgrid[:180,:320];clip=np.stack((2*(xx+.5)/320-1,2*(yy+.5)/180-1,a['Depth'][...,0],np.ones((180,320))),-1);inv=matrix(m['frames'][0]['inverseJitteredViewProjection']);world=clip@inv.T;world=world[...,:3]/world[...,3:];plane=(abs(world[...,1])<.02)&(abs(world[...,0])<2.7)&(abs(world[...,2])<2.7)
 report[name]={'producerFrame':s['producerFrame'],'producerDistinct':s['producerDistinct'],'materialSpecularLevel':s['frameState']['specularLevel'],'planePixels':int(plane.sum()),'gbufferSpecularRange':[float(a['GBufferB'][plane,3].min()),float(a['GBufferB'][plane,3].max())],'gbufferRoughnessRange':[float(a['GBufferA'][plane,2].min()),float(a['GBufferA'][plane,2].max())],'gbufferMetallicRange':[float(a['GBufferA'][plane,3].min()),float(a['GBufferA'][plane,3].max())],'gbufferLuminanceMedian':float(np.median(a['GBufferA'][plane,0])),'bakingOutput':s['frameState']['bakingOutput'],'lightDump':s['frameState']['lightDump'],'cameraFrame':m['frames'][0]['frame'],'rawSha':{b['semantic']:hashlib.sha256((root/'frames'/b['file']).read_bytes()).hexdigest() for b in m['buffers']}}
 assert report[name]['gbufferSpecularRange']==[0,0] and report[name]['gbufferRoughnessRange']==[1,1] and report[name]['gbufferMetallicRange']==[0,0]
 for j,sem in enumerate(['BakedDiffuse','Lighting','DisplayColor']):
  rgb=np.flipud(a[sem][...,:3]);rgb=rgb/(1+rgb) if sem=='BakedDiffuse' else rgb;rgb=np.where(rgb<=.0031308,12.92*rgb,1.055*np.maximum(rgb,0)**(1/2.4)-.055);canvas.paste(Image.fromarray((np.clip(rgb,0,1)*255).astype('uint8')),(j*320,ci*210+30));draw.text((j*320+5,ci*210+8),name+' '+sem,fill='white')
 data[name]=(a,m)
# Use an identical world grid, separately reprojected through each frame's actual jittered VP.
z,x=np.mgrid[-1.6:1.6:201j,-1.6:1.6:201j];r=np.sqrt(x*x+z*z);roi=(r>.1)&(r<1.8);points=np.stack([x,np.zeros_like(x),z,np.ones_like(x)],-1);values={}
for name,(a,m) in data.items():
 clip=points@matrix(m['frames'][0]['jitteredViewProjection']).T;ndc=clip[...,:3]/clip[...,3:];px=(ndc[...,0]*.5+.5)*320-.5;py=(ndc[...,1]*.5+.5)*180-.5;values[name]=sample(a['Lighting'][...,:3],px,py).mean(-1)
ratio=values['spot-mixed'][roi]/values['spot-baked'][roi];difference=values['spot-mixed'][roi]-values['spot-baked'][roi];report['comparison']={'worldGridSamples':int(roi.sum()),'roi':'receiver y0; radius .1..1.8m; no caster','mixedOverBakedMedian':float(np.median(ratio)),'ratioP05':float(np.percentile(ratio,5)),'ratioP95':float(np.percentile(ratio,95)),'relativeErrorMedian':float(np.median(abs(ratio-1))),'relativeErrorP95':float(np.percentile(abs(ratio-1),95)),'differenceMedian':float(np.median(difference)),'bothUseOwnJitteredVP':True,'notPiCompensated':True}
(P/'fixed-spot-analysis.json').write_text(json.dumps(report,indent=2));canvas.save(P/'fixed-spot-contact.png');print(json.dumps({k:v for k,v in report.items() if k=='comparison'},indent=2));print({name:{k:report[name][k] for k in ['gbufferSpecularRange','gbufferRoughnessRange','gbufferMetallicRange','gbufferLuminanceMedian']} for name in ['spot-baked','spot-mixed']})
