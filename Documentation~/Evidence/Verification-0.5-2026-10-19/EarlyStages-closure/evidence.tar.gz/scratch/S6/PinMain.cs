using System;using System.IO;using System.Linq;using System.Reflection;using UnityEditor;using UnityEngine;using UnityEngine.Rendering;using InfinityTech.Rendering.Pipeline;
public static class S6ConfigureMain {
 const string Root="/Volumes/DataDisk/Projects/Unity/InfinityExample/intermediate/verification-0.5/20261020-run02/S6";
 public static object Run(){if(EditorApplication.isCompiling||EditorApplication.isPlaying)throw new Exception("Idle required");
 var gs=InfinityRenderPipelineGlobalSettings.Require();var original=EditorJsonUtility.ToJson(gs,true);if(!File.Exists(Root+"/main-gs-original.json"))File.WriteAllText(Root+"/main-gs-original.json",original);
 GraphicsSettings.TryGetRenderPipelineSettings(out InfinityRenderPipelineRuntimeShaders shaders);GraphicsSettings.TryGetRenderPipelineSettings(out InfinityDefaultVolumeProfileSettings defaults);
 var changes=new System.Collections.Generic.List<string>();
 foreach(var f in shaders.GetType().GetFields(BindingFlags.Public|BindingFlags.Instance)){
 if(!typeof(UnityEngine.Object).IsAssignableFrom(f.FieldType)||(UnityEngine.Object)f.GetValue(shaders))continue;
 var attr=f.CustomAttributes.SingleOrDefault(a=>a.AttributeType.Name=="ResourcePathAttribute");if(attr==null)continue;
 var rel=(string)attr.ConstructorArguments[0].Value;var path=InfinityRenderPipelineRuntimeShaders.PackagePath+"/"+rel;var value=AssetDatabase.LoadAssetAtPath(path,f.FieldType);if(!value)throw new Exception("Missing "+path);f.SetValue(shaders,value);changes.Add(f.Name+"="+path);
 }
 var profile=DefaultVolumeProfileFactory.CreateInMemory();profile.name="S6 Main verification memory defaults";profile.hideFlags=HideFlags.HideAndDontSave;foreach(var c in profile.components)c.hideFlags=HideFlags.HideAndDontSave;defaults.volumeProfile=profile;changes.Add("defaultProfile="+profile.name);
 File.WriteAllText(Root+"/main-memory-config-pinned.json",Newtonsoft.Json.JsonConvert.SerializeObject(new {pid=System.Diagnostics.Process.GetCurrentProcess().Id,changes,originalDirty=EditorUtility.IsDirty(gs),configured=EditorJsonUtility.ToJson(gs)},Newtonsoft.Json.Formatting.Indented));
 return new {changes,requiredDefaults=DefaultVolumeProfileFactory.HasRequiredDefaultComponents(profile),saved=false};}
}
