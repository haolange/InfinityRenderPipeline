from pathlib import Path
import sys,subprocess,json,time,os,re,hashlib,datetime
project='/Volumes/DataDisk/Projects/Unity/InfinityExample';cli='/Users/gushihao/.unity/bin/unity'
root=Path(project+'/intermediate/verification-0.5/20261020-run02/S6');label=sys.argv[1]
assert re.fullmatch('[a-z0-9-]+',label)
state=json.loads(subprocess.run([cli,'status','--project-path',project,'--format','json'],capture_output=True,text=True).stdout)
assert not state.get('data',{}).get('instances',[]),'Original Example already running'
# Authorized sidecars only. No hashing, mutation or copy when none exist.
d=Path(project+'/Library/DataStore');pat=re.compile(r'(?:\._UDSData_[0-9]+\.bin|\._uds\.db|\._uds\.db-lock|\._uds\.lock)')
candidates=[f for f in d.iterdir() if pat.fullmatch(f.name)]
assert not candidates,'Run recorded exact-sidecar validation before this launch'
p=subprocess.run([cli,'open',project,'--editor-path','/Users/gushihao/CGFiles/Engines/Unity/6000.6.0f1/Unity.app','--args','-logFile '+str(root/(label+'-Editor.log')),'--format','json'],capture_output=True,text=True)
(root/(label+'-open.json')).write_text(p.stdout);print(p.stdout,flush=True);assert p.returncode==0
pid=json.loads(p.stdout)['data']['launchedPid']
(root/(label+'-pid.json')).write_text(json.dumps({'pid':pid,'project':project}))
ready=False
while True:
 try:os.kill(pid,0)
 except ProcessLookupError:break
 if not ready:
  s=subprocess.run([cli,'status','--project-path',project,'--format','json'],capture_output=True,text=True)
  try:j=json.loads(s.stdout)
  except Exception:j={}
  ins=j.get('data',{}).get('instances',[])
  if any(i.get('pid')==pid and i.get('state')=='ready' for i in ins):
   ready=True;(root/(label+'-ready.json')).write_text(s.stdout);print('OWNED READY '+str(pid),flush=True)
 time.sleep(2)
print('Owned Editor exited '+str(pid),flush=True)
