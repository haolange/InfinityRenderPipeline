from pathlib import Path
import subprocess,json,time
p=Path(__file__).parent
cases=[('angular','LightAngularGpuTests',False,3),('shape','LightShapeTests',False,23),('record','LightRecordTests',False,9),('layout','LightRecordLayoutTests',False,2),('lifecycle','QualityLifecycleTests',False,11),('full','',True,1604)]
for suffix,filter_,all_,expected in cases:
 label='spot-historical-'+suffix;folder=p/label
 if folder.exists():raise RuntimeError('Existing output '+label)
 args=['/Users/gushihao/.unity/bin/unity','command','run_script','--file',str(p/'HistoricalSpotTests.cs'),'--entry','S6HistoricalSpotTests.Run','--args',json.dumps([label,filter_,all_]),'--caller','plugin','--skill','unity-cli','--project-path','/Volumes/DataDisk/Projects/Unity/InfinityExample','--format','json']
 r=subprocess.run(args,capture_output=True,text=True);(p/(label+'-start.json')).write_text(r.stdout);j=json.loads(r.stdout)
 if r.returncode or not j.get('data',{}).get('result',{}).get('success'):raise RuntimeError(r.stdout)
 print('STARTED '+label,flush=True);deadline=time.monotonic()+900
 while time.monotonic()<deadline:
  try:s=json.loads((folder/'run.json').read_text())
  except (FileNotFoundError,json.JSONDecodeError):s={}
  if s.get('status') in ['Completed','Failed','Canceled','Cancelled','ResumeFailed']:
   print(label,json.dumps({k:s.get(k) for k in ['status','discovered','started','finished','passed','failed','skipped','callbacksComplete','reloadCount','resumedCount']}),flush=True)
   if s.get('status')!='Completed' or not s.get('callbacksComplete') or s.get('discovered')!=expected or s.get('finished')!=expected or s.get('failed') or s.get('inconclusive') or (suffix!='full' and s.get('skipped')):raise RuntimeError('Gate rejected '+label)
   break
  time.sleep(1)
 else:raise RuntimeError('Test timeout '+label)
