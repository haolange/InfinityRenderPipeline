using System;
using System.IO;
using System.Reflection;
using UnityEngine;
using UnityEditor;
using UnityEngine.Rendering;
using InfinityTech.Component;
using InfinityTech.Rendering.Pipeline;
using GI=UnityEngine.Experimental.GlobalIllumination.Lightmapping;
public static class S6LifecycleProbe {
 const string Root="/Volumes/DataDisk/Projects/Unity/InfinityExample/intermediate/verification-0.5/20261020-run02/S6";
 public static object Run() {
 if(EditorApplication.isCompiling || EditorApplication.isPlaying) throw new Exception("Idle EditMode required");
 var beforeScene=UnityEditor.SceneManagement.EditorSceneManager.GetActiveScene();
 var scene=UnityEditor.SceneManagement.EditorSceneManager.NewPreviewScene();
 var go=new GameObject("S6 owned legacy light"); UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(go,scene);
 var marker=new GameObject("S6 owned Undo sentinel"); UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(marker,scene);
 UnityEditor.Editor editor=null;
 var originalDelegate=GI.GetDelegate();
 GraphicsSettings.TryGetRenderPipelineSettings(out InfinityDefaultVolumeProfileSettings profileSettings);
 var oldProfile=profileSettings.volumeProfile;
 var profile=DefaultVolumeProfileFactory.CreateInMemory();
 string before="",after="",afterUndo=""; bool markerUndone=false,delegInstalled=false,delegRestored=false;
 object pipeline=null; Type type=typeof(InfinityRenderPipeline); const BindingFlags flags=BindingFlags.Instance|BindingFlags.NonPublic;
 try {
 var light=go.AddComponent<Light>();light.type=LightType.Rectangle;light.areaSize=new Vector2(3,1);
 var ext=go.AddComponent<InfinityAdditionalLightData>();var so=new SerializedObject(ext);so.FindProperty("m_ShapeAuthored").boolValue=false;so.ApplyModifiedPropertiesWithoutUndo();
 before=EditorJsonUtility.ToJson(ext);
 Undo.IncrementCurrentGroup();Undo.SetCurrentGroupName("S6 owned adoption sentinel");Undo.RecordObject(marker.transform,"S6 owned sentinel");marker.transform.position=Vector3.one;Undo.FlushUndoRecordObjects();
 editor=UnityEditor.Editor.CreateEditor(light);
 after=EditorJsonUtility.ToJson(ext);Undo.FlushUndoRecordObjects();Undo.PerformUndo();
 afterUndo=EditorJsonUtility.ToJson(ext);markerUndone=marker.transform.position==Vector3.zero;
 profileSettings.volumeProfile=profile;
 pipeline=typeof(System.Runtime.CompilerServices.RuntimeHelpers).GetMethod("GetUninitializedObject").Invoke(null,new object[]{type});
 type.GetField("resources",flags).SetValue(pipeline,new InfinityRenderPipelineResources());
 type.GetField("m_PipelineAsset",flags).SetValue(pipeline,GraphicsSettings.currentRenderPipeline);
 GI.RequestLightsDelegate sentinel=(requests,output)=>{};GI.SetDelegate(sentinel);
 type.GetMethod("CaptureGraphicsState",flags).Invoke(pipeline,null);
 type.GetMethod("SetGraphicsSetting",flags).Invoke(pipeline,null);
 delegInstalled=GI.GetDelegate()==InfinityLightmapperDelegate.Delegate;
 type.GetMethod("RestoreGraphicsState",flags).Invoke(pipeline,null);
 delegRestored=GI.GetDelegate()==sentinel;
 var evidence=new {pid=System.Diagnostics.Process.GetCurrentProcess().Id,unity=Application.unityVersion,editor=editor.GetType().FullName,before,after,afterUndo,adoptionChanged=before!=after,adoptionUndoRestored=before==afterUndo,markerUndone,delegInstalled,delegRestored,sourceSceneStillClean=!beforeScene.isDirty};
 File.WriteAllText(Root+"/lifecycle-original.json",Newtonsoft.Json.JsonConvert.SerializeObject(evidence,Newtonsoft.Json.Formatting.Indented));
 return evidence;
 } finally {
 if(pipeline!=null)type.GetMethod("RestoreGraphicsState",flags).Invoke(pipeline,null);
 GI.SetDelegate(originalDelegate);profileSettings.volumeProfile=oldProfile;
 if(editor)UnityEngine.Object.DestroyImmediate(editor);
 foreach(var c in go.GetComponents<Component>())if(c)Undo.ClearUndo(c);Undo.ClearUndo(marker.transform);
 UnityEditor.SceneManagement.EditorSceneManager.ClosePreviewScene(scene);
 foreach(var c in profile.components)if(c)UnityEngine.Object.DestroyImmediate(c);UnityEngine.Object.DestroyImmediate(profile);
 }
 }
}
