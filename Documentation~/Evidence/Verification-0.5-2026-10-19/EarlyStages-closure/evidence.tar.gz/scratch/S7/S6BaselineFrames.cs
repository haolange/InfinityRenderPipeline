using System;using System.IO;using System.Linq;using System.Reflection;using System.Collections.Generic;using System.Text;using UnityEditor;using UnityEngine;using UnityEngine.Rendering;using UnityEngine.SceneManagement;using InfinityTech.Component;using InfinityTech.Rendering.LightPipeline;using InfinityTech.Rendering.Pipeline;
public static class S6BaselineFrames {
 const string Root="/Volumes/DataDisk/Projects/Unity/InfinityExample/intermediate/verification-0.5/20261020-run02/S7/s6-baseline-parent";
 static Session current;
 public static object Start(){if(!Application.isPlaying)throw new Exception("Play required");if(current!=null)throw new Exception("Already started");var service=typeof(InfinityRenderPipeline).Assembly.GetType("InfinityTech.Rendering.Pipeline.RenderCaptureService",true);var active=service.GetField("current",BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public).GetValue(null);if(active!=null&&!(bool)active.GetType().GetProperty("Finished",BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public).GetValue(active))throw new Exception("Existing capture must drain");current=new Session();current.Initialize();try{return current.Choose("upper");}catch(Exception e){current.FailStartup(e);throw;}}
 public static object Control(string action){if(current==null)throw new Exception("No session");if(action=="status")return current.State();if(action=="finish")return current.Finish();return current.Choose(action);}
 sealed class Session {
 const BindingFlags All=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;
 readonly List<Camera> oldCameras=new List<Camera>();readonly List<Light> oldLights=new List<Light>();readonly List<UnityEngine.Object> resources=new List<UnityEngine.Object>();
 Scene scene;Camera camera;Light light;Material material;GameObject receiver;InfinityAdditionalLightData ext;readonly bool oldBackground;readonly float oldScale;readonly EditorWindow gameView;
 string name,status="Preparing",error;int normalFrames;object native;object production;double started;object capture;bool finished;bool terminalAttempted;bool cancelSent;bool restoring;readonly SortedDictionary<int,object> productionFrames=new SortedDictionary<int,object>();
 readonly Type service=typeof(InfinityRenderPipeline).Assembly.GetType("InfinityTech.Rendering.Pipeline.RenderCaptureService",true);
 readonly Type cli=Type.GetType("InfinityTech.Rendering.Editor.RenderingValidationCommands, Unity.RenderPipelines.Infinity.Cli.Editor",true);
 public Session(){if(UnityEngine.Object.FindObjectsByType<GameObject>().Any(g=>g.layer==30))throw new Exception("Layer30 occupied");
 gameView=Resources.FindObjectsOfTypeAll<EditorWindow>().Single(w=>w.GetType().FullName=="UnityEditor.GameView");oldBackground=Application.runInBackground;oldScale=Time.timeScale;
 }
 public void Initialize(){Directory.CreateDirectory(Root);EditorApplication.update+=Tick;try{scene=SceneManager.GetActiveScene();if(scene.path!="Assets/Scene/Spazon/Scene_Spazon.unity")throw new Exception("Wrong source scene");foreach(var c in Camera.allCameras)if(c.enabled){oldCameras.Add(c);c.enabled=false;}foreach(var l in UnityEngine.Object.FindObjectsByType<Light>())if(l.enabled){oldLights.Add(l);l.enabled=false;}
 var cg=New("S7-Camera");camera=cg.AddComponent<Camera>();camera.orthographic=true;camera.orthographicSize=4;camera.nearClipPlane=.1f;camera.farClipPlane=300;camera.cullingMask=1<<30;camera.pixelRect=new Rect(0,0,320,180);camera.transform.SetPositionAndRotation(new Vector3(0,0,-8),Quaternion.identity);cg.AddComponent<InfinityAdditionalCameraData>().volumeLayerMask=0;
 var shader=Shader.Find("InfinityPipeline/InfinityLit-Instanced");if(!shader)throw new Exception("Lit shader absent");material=new Material(shader);material.enableInstancing=true;resources.Add(material);material.SetColor("_BaseColor",new Color(.5f,.5f,.5f));material.SetFloat("_Roughness",.65f);material.SetFloat("_SpecularLevel",0);material.SetFloat("_Metallic",0);MaterialRouteUtility.ApplyPassState(material);
 var mesh=new Mesh();resources.Add(mesh);mesh.vertices=new[]{new Vector3(-6,-4,0),new Vector3(6,-4,0),new Vector3(-6,4,0),new Vector3(6,4,0)};mesh.normals=Enumerable.Repeat(Vector3.back,4).ToArray();mesh.uv=new[]{Vector2.zero,Vector2.right,Vector2.up,Vector2.one};mesh.triangles=new[]{0,2,1,2,3,1};mesh.RecalculateBounds();
 receiver=New("S7-Receiver");receiver.SetActive(false);receiver.transform.position=new Vector3(0,0,3);receiver.AddComponent<MeshFilter>().sharedMesh=mesh;receiver.AddComponent<MeshRenderer>().sharedMaterial=material;var proxy=receiver.AddComponent<MeshComponent>();proxy.movebility=InfinityTech.Rendering.MeshPipeline.EStateType.Dynamic;proxy.meshAsset=mesh;proxy.materials=new[]{material};receiver.SetActive(true);
 var lg=New("S7-Owned-Light");light=lg.AddComponent<Light>();light.intensity=30;light.range=50;light.color=Color.white;light.cullingMask=1<<30;light.shadows=LightShadows.None;light.lightmapBakeType=LightmapBakeType.Realtime;light.transform.position=new Vector3(0,0,-1);ext=lg.AddComponent<InfinityAdditionalLightData>();ext.maxDrawDistance=0;
 Application.runInBackground=true;Time.timeScale=0;
 RenderPipelineManager.endCameraRendering+=End;gameView.Focus();
 }catch(Exception original){error=original.ToString();try{BeginRestore();}catch(Exception cleanup){error+="\nCleanup: "+cleanup;}throw;}}
 GameObject New(string n){var go=new GameObject(n);go.hideFlags=HideFlags.DontSave;resources.Add(go);go.layer=30;SceneManager.MoveGameObjectToScene(go,scene);return go;}
 public object Choose(string next){if(finished||restoring||(status!="Preparing"&&status!="Captured"))throw new Exception("Session not ready: "+status);if(capture!=null&&!Done())throw new Exception("Capture draining");if(Directory.Exists(Root+"/frames/"+next))throw new Exception("Case already exists");
 var shape=FLightShape.Default(EInfinityLightType.Point);camera.transform.SetPositionAndRotation(new Vector3(0,0,-8),Quaternion.identity);light.transform.rotation=Quaternion.identity;light.enabled=true;light.intensity=30;ext.maxDrawDistance=0;ext.maxDrawDistanceFade=4;
 camera.orthographic=true;camera.orthographicSize=4;camera.nearClipPlane=.1f;camera.farClipPlane=300;camera.cullingMask=1<<30;light.transform.position=new Vector3(0,2,2);light.range=2;receiver.transform.position=new Vector3(0,0,3);material.SetFloat("_SurfaceRoute",0);
 switch(next){case "upper":break;case "lower":light.transform.position=new Vector3(0,-2,2);break;case "off":light.enabled=false;break;case "forward-upper":material.SetFloat("_SurfaceRoute",1);break;
 case "inside":light.transform.position=camera.transform.position;light.range=20;break;case "behind":light.transform.position=new Vector3(0,0,-12);light.range=1;break;case "offscreen":light.transform.position=new Vector3(100,0,0);light.range=1;break;
 case "far0":case "far75":case "far125":camera.transform.position=new Vector3(0,0,next=="far0"?0:next=="far75"?75:125);light.transform.position=new Vector3(0,0,153);light.range=5;receiver.transform.position=new Vector3(0,0,155);break;
 default:throw new Exception("Unknown case "+next);}
 MaterialRouteUtility.ApplyPassState(material);
 ext.SetShape(shape);light.lightmapBakeType=LightmapBakeType.Realtime;light.spotAngle=60;light.innerSpotAngle=20;
 name=next;status="Capturing";normalFrames=0;productionFrames.Clear();cancelSent=false;terminalAttempted=false;error=null;started=EditorApplication.timeSinceStartup;native=null;production=null;
 var request=new {outputDirectory=Root+"/frames/"+next,fixture="S7-shapes-"+next,scene=scene.name,camera=camera.name,cameraType=(int)CameraType.Game,requestRepaint=true,width=320,height=180,warmupFrames=32,frameCount=1,frameInterval=1,timeoutSeconds=90,includeConfidence=false,buffers=new[]{"Lighting","Depth","DisplayColor"}};
 var requestFile=Root+"/request-"+next+".json";var rt=service.Assembly.GetType("InfinityTech.Rendering.Pipeline.RenderCaptureRequest",true);var rq=JsonUtility.FromJson(Newtonsoft.Json.JsonConvert.SerializeObject(request),rt);rt.GetField("roi").SetValue(rq,new RectInt(0,0,320,180));File.WriteAllText(requestFile,JsonUtility.ToJson(rq,true));cli.GetMethod("CaptureStart",All).Invoke(null,new object[]{requestFile});capture=service.GetField("current",All).GetValue(null);Save();return State();}
 bool Done()=>capture==null||(bool)capture.GetType().GetProperty("Finished",All).GetValue(capture);
 void End(ScriptableRenderContext context,Camera c){if(c!=camera||finished||status!="Capturing")return;normalFrames++;production=new{frame=Time.frameCount,normalFrames};productionFrames[Time.frameCount]=production;while(productionFrames.Count>128)productionFrames.Remove(productionFrames.Keys.First());}
 public void FailStartup(Exception e)=>Fail(e);
 void SaveTerminal(){if(terminalAttempted)return;terminalAttempted=true;try{Save();}catch(Exception e){if(error==null)error=e.ToString();status="PersistenceFailed";}}
 void Fail(Exception e){if(error==null)error=e.ToString();status="Error";}
 void ValidateCapture(){var path=Root+"/frames/"+name+"/capture.json";var meta=Newtonsoft.Json.Linq.JObject.Parse(File.ReadAllText(path));
 if((string)meta["status"]!="Completed"||!string.IsNullOrEmpty((string)meta["error"])||!string.IsNullOrEmpty((string)meta["persistenceError"])||(int)meta["capturedFrames"]!=1||(int)meta["outstanding"]!=0||(int)meta["successfulFrames"]<33)throw new Exception("Capture terminal evidence rejected: "+meta["status"]);
 var buffers=(Newtonsoft.Json.Linq.JArray)meta["buffers"];var semantics=buffers.Select(v=>(string)v["semantic"]).OrderBy(v=>v).ToArray();if(!semantics.SequenceEqual(new[]{"Depth","DisplayColor","Lighting"}.OrderBy(v=>v)))throw new Exception("Missing/extra capture buffers");
 foreach(var v in buffers){if(!(bool)v["submitted"]||!(bool)v["readbackTerminal"]||!(bool)v["retired"]||!string.IsNullOrEmpty((string)v["error"])||(long)v["statistics"]["nonFinite"]!=0)throw new Exception("Invalid buffer terminal evidence");var raw=Root+"/frames/"+name+"/"+(string)v["file"];if(new FileInfo(raw).Length!=(long)v["bytes"])throw new Exception("Raw byte count mismatch");}
 var frame=buffers.Select(v=>(int)v["producerFrame"]).Distinct().Single();if(productionFrames.Keys.Count(f=>f<=frame)<33)throw new Exception("Insufficient distinct camera frames before capture");if(!productionFrames.TryGetValue(frame,out production))throw new Exception("No matching production frame "+frame);native=null;
 }
 void Tick(){if(finished)return;try{if(restoring){if(resources.All(o=>!o)){finished=true;status="Restored";EditorApplication.update-=Tick;File.WriteAllText(Root+"/restore.json",Newtonsoft.Json.JsonConvert.SerializeObject(State(),Newtonsoft.Json.Formatting.Indented));}return;}
 if(status=="Capturing"&&Done()){ValidateCapture();status="Captured";SaveTerminal();}
 if(status=="Capturing"&&EditorApplication.timeSinceStartup-started>100)Fail(new Exception("Case timeout"));
 if(status=="Error"){if(!cancelSent){cancelSent=true;cli.GetMethod("CaptureCancel",All).Invoke(null,null);}if(Done()){status="Failed";SaveTerminal();}}
 if(status=="Capturing"||status=="Error"){EditorApplication.QueuePlayerLoopUpdate();gameView.Repaint();}}
 catch(Exception e){Fail(e);}}
 object CaptureState()=>cli.GetMethod("CaptureStatus",All).Invoke(null,null);
 public object State()=>new{status,name,error,layer=30,normalFrames,native,production,capture=CaptureState(),finished};
 void Save(){Directory.CreateDirectory(Root+"/frame-state");File.WriteAllText(Root+"/frame-state/"+name+".json",Newtonsoft.Json.JsonConvert.SerializeObject(State(),Newtonsoft.Json.Formatting.Indented));}
 void BeginRestore(){if(restoring)return;restoring=true;RenderPipelineManager.endCameraRendering-=End;foreach(var c in oldCameras)if(c)c.enabled=true;foreach(var l in oldLights)if(l)l.enabled=true;Application.runInBackground=oldBackground;Time.timeScale=oldScale;foreach(var o in resources)if(o)UnityEngine.Object.Destroy(o);status="Restoring";}
 public object Finish(){if(!Done()){if(!cancelSent){cancelSent=true;cli.GetMethod("CaptureCancel",All).Invoke(null,null);}return new{status="Draining"};}if(!finished)BeginRestore();return State();}
 }
}
