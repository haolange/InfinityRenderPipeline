from pathlib import Path
import json,numpy as np,hashlib,struct,zlib
r=Path(__file__).parent;root=r/'main-normal-no-diagnostics';names=['upper','lower','off','forward-upper','inside','behind','offscreen','far0','far75','far125'];arrays={};report={}
for name in names:
 folder=root/'frames'/name;j=json.loads((folder/'capture.json').read_text());state=json.loads((root/'frame-state'/(name+'.json')).read_text());assert j['status']=='Completed' and j['successfulFrames']==33 and j['capturedFrames']==1 and j['outstanding']==0 and not j.get('error') and state['status']=='Captured' and not state.get('error');assert sorted(b['semantic'] for b in j['buffers'])==['Depth','DisplayColor','Lighting']
 for b in j['buffers']:
  assert b['submitted'] and b['readbackTerminal'] and b['retired'] and b['statistics']['nonFinite']==0 and (folder/b['file']).stat().st_size==b['bytes']
 b=next(b for b in j['buffers'] if b['semantic']=='Lighting');arrays[name]=np.fromfile(folder/b['file'],dtype='<f2').astype(np.float32).reshape(180,320,4)[:,:,:3];report[name]={'producerFrame':b['producerFrame'],'normalFrames':state['normalFrames'],'sourceSHA':hashlib.sha256((folder/b['file']).read_bytes()).hexdigest(),'center':arrays[name][90,160].tolist()}
off=arrays['off']
for name in names:
 delta=arrays[name]-off;peak=np.unravel_index(np.argmax(delta.mean(2)),(180,320));report[name].update(positivePixelCount=int((delta.max(2)>.001).sum()),peakRawRowColumn=[int(v) for v in peak],maximumMeanIncrement=float(delta.mean(2).max()))
for name in ['upper','lower','forward-upper']:assert report[name]['positivePixelCount']>4000
for name in ['behind','offscreen']:assert report[name]['positivePixelCount']==0
assert report['inside']['positivePixelCount']>48000
(r/'main-normal-frame-gate.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
panels=[]
for name in ['upper','lower','forward-upper','inside']:
 folder=root/'frames'/name;j=json.loads((folder/'capture.json').read_text());b=next(b for b in j['buffers'] if b['semantic']=='DisplayColor');a=np.fromfile(folder/b['file'],dtype='<f2').astype(np.float32).reshape(180,320,4)[:,:,:3];a=np.clip(a,0,1);s=np.where(a<=.0031308,a*12.92,1.055*a**(1/2.4)-.055);panels.append(np.round(s[::-1]*255).astype(np.uint8))
a=np.concatenate([np.concatenate(panels[:2],axis=1),np.concatenate(panels[2:],axis=1)],axis=0);h,w=a.shape[:2]
def chunk(t,b):return struct.pack('>I',len(b))+t+b+struct.pack('>I',zlib.crc32(t+b)&0xffffffff)
raw=b''.join(b'\x00'+row.tobytes() for row in a);png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'');(r/'main-normal-display-grid.png').write_bytes(png)
