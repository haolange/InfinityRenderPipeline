from pathlib import Path
import json,numpy as np,tarfile,hashlib
r=Path(__file__).parent
js=[json.loads((r/('volumetric-s6-synced-cloud-on/capture.json' if s=='s6' else 'volumetric-s7-rephased-cloud-on/capture.json')).read_text()) for s in ['s6','s7']];maps=[{f['frame']%16:f for f in j['frames']} for j in js];assert len(maps[0])==len(maps[1])==16
archive=tarfile.open(r/'closed-s6-synced-cloud.tar.gz');rows=[]
for phase in range(16):
 fs=[m[phase] for m in maps]
 for key in ['position','rotation','view','projection','currentJitterUV','jitteredViewProjection','inverseJitteredViewProjection','historyReset']:
  assert fs[0][key]==fs[1][key],(phase,key,fs[0][key],fs[1][key])
 for semantic in ['VolumetricCloud','SceneColor']:
  bs=[next(b for b in j['buffers'] if b['semantic']==semantic and b['producerFrame']==f['frame']) for j,f in zip(js,fs)];raw=[archive.extractfile('volumetric-s6-synced-cloud-on/'+bs[0]['file']).read(),(r/'volumetric-s7-rephased-cloud-on'/bs[1]['file']).read_bytes()];arrays=[np.frombuffer(b,dtype='<f2').astype(np.float32).reshape(-1,4) for b in raw];assert all(np.isfinite(a).all() for a in arrays);d=np.abs(arrays[0]-arrays[1]);rows.append(dict(phase=phase,frames=[f['frame'] for f in fs],semantic=semantic,rgbaMax=d.max(axis=0).tolist(),rgbaMean=d.mean(axis=0).tolist(),rgbRelativeL1=float(d[:,:3].sum()/max(np.abs(arrays[0][:,:3]).sum(),1e-20)),rawSHA=[hashlib.sha256(b).hexdigest() for b in raw]))
(r/'synced-cloud-comparison.json').write_text(json.dumps({'matching':'actual frame&15 plus exact jittered matrices/current jitter/history reset; RGB and alpha separately','rows':rows},indent=2))
for semantic in ['VolumetricCloud','SceneColor']:
 z=[x for x in rows if x['semantic']==semantic];print(semantic,'maxRGBA',np.max([x['rgbaMax'] for x in z],axis=0).tolist(),'maxL1',max(x['rgbRelativeL1'] for x in z))
