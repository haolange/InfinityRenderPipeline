from pathlib import Path
import json,numpy as np,hashlib
r=Path(__file__).parent
report={"scope":"S6 accepted predecessors vs S7 candidate; constant-density runtime fixtures, no scene saves", "comparisons":[]}
for kind in ['fog','cloud']:
 ds=[r/('volumetric-'+stage+'-matched-'+kind+'-on') for stage in ['s6','s7']]
 js=[json.loads((d/'capture.json').read_text()) for d in ds]
 proof=[json.loads((d/'volume-proof.json').read_text()) for d in ds]
 assert proof[0]['fog']==proof[1]['fog'] and proof[0]['cloud']==proof[1]['cloud']
 assert {q['record'] for q in proof[0]['records']}=={q['record'] for q in proof[1]['records']}
 maps=[{tuple(f['currentJitterUV'][k] for k in ['x','y']):f for f in j['frames']} for j in js]
 assert len(maps[0])==len(maps[1])==8 and maps[0].keys()==maps[1].keys()
 for phase in sorted(maps[0]):
  fs=[m[phase] for m in maps]
  for key in ['position','rotation','view','projection','width','height']:assert fs[0][key]==fs[1][key],key
  for semantic in (['Lighting','SceneColor'] if kind=='fog' else ['VolumetricCloud','SceneColor']):
   bs=[next(b for b in j['buffers'] if b['semantic']==semantic and b['producerFrame']==f['frame']) for j,f in zip(js,fs)]
   arrays=[np.fromfile(d/b['file'],dtype='<f2').astype(np.float32).reshape(b['height'],b['width'],4)[:,:,:3] for d,b in zip(ds,bs)]
   assert all(np.isfinite(a).all() and np.max(np.abs(a))<65504 for a in arrays)
   a,b=arrays;delta=np.abs(a-b)
   report['comparisons'].append(dict(kind=kind,semantic=semantic,jitter=phase,frames=[f['frame'] for f in fs],maxAbsolute=float(delta.max()),meanAbsolute=float(delta.mean()),relativeL1=float(delta.sum()/max(np.abs(a).sum(),1e-20)),means=[float(x.mean()) for x in arrays],nonzero=[int(np.count_nonzero(x)) for x in arrays],rawSHA256=[hashlib.sha256((d/q['file']).read_bytes()).hexdigest() for d,q in zip(ds,bs)]))
(r/'matched-volumetric-s6-s7-comparison.json').write_text(json.dumps(report,indent=2))
for kind in ['fog','cloud']:
 for sem in ['Lighting','SceneColor','VolumetricCloud']:
  rows=[x for x in report['comparisons'] if x['kind']==kind and x['semantic']==sem]
  if rows:print(kind,sem,'max',max(x['maxAbsolute'] for x in rows),'L1',max(x['relativeL1'] for x in rows),'means',rows[0]['means'])
