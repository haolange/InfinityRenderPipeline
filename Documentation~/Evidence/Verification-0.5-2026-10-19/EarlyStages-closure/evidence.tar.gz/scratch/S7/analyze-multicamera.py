from pathlib import Path
import json,numpy as np
r=Path(__file__).parent
def read(folder):
 j=json.loads((folder/'capture.json').read_text());b=next(b for b in j['buffers'] if b['semantic']=='Lighting');a=np.fromfile(folder/b['file'],dtype='<f2').astype(np.float64).reshape(180,320,4);f=j['frames'][0];return a,f
single,sf=read(r/'final-normal-no-diagnostics/frames/upper');off,_=read(r/'final-normal-no-diagnostics/frames/off');multi,mf=read(r/'multi-after');empty,_=read(r/'multi-before');runs={}
# Every pixel, positive red-channel increment with an explicit .001 threshold. Float64 accumulation.
y,x=np.indices((180,320))
for name,a,f in [('single',single,sf),('multi',multi,mf)]:
 w=np.maximum(a[:,:,0]-off[:,:,0],0);w[w<=.001]=0;total=w.sum();runs[name]=dict(sumPositiveRed=float(total),centroid=[float((w*x).sum()/total),float((w*y).sum()/total)],jitterPixels=[f['currentJitterUV']['x']*320,f['currentJitterUV']['y']*180])
delta=np.abs(empty[:,:,:3]-off[:,:,:3]);report=dict(definition='Full320x180; positive red increment over off, threshold>.001; float64 sums. Empty target RGB inner ROI x30:290 y5:175 separately from full image.',runs=runs,relativeEnergyDifference=abs(runs['multi']['sumPositiveRed']/runs['single']['sumPositiveRed']-1),emptyTargetInnerROIMaxAbs=float(delta[5:175,30:290].max()),emptyTargetFullImageMaxAbs=float(delta.max()))
report['centroidDeltaPixels']=(np.array(runs['multi']['centroid'])-runs['single']['centroid']).tolist();report['jitterDeltaPixels']=(np.array(runs['multi']['jitterPixels'])-runs['single']['jitterPixels']).tolist();report['centroidResidualAfterJitter']=(np.array(report['centroidDeltaPixels'])-report['jitterDeltaPixels']).tolist();(r/'multicamera-explicit-analysis.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
