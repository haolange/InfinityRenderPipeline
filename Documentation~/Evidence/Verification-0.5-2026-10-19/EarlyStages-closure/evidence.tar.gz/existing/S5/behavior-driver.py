from pathlib import Path
import subprocess,json,time,sys
r=Path(__file__).parent
cli='/Users/gushihao/.unity/bin/unity'
def call(entry,file='behavior-control.cs'):
 p=subprocess.run([cli,'command','run_script','--file',str(r/file),'--entry',entry,'--project-path','/Volumes/DataDisk/Projects/Unity/InfinityExample','--format','json'],capture_output=True,text=True,timeout=25);j=json.loads(p.stdout);assert j['success'] and j['data']['result']['success'],j;return j['data']['result'].get('result')
for mode in sys.argv[1:]:
 cfg=dict(label='behavior-'+mode,mode=mode,warmup=0 if mode in ('age','quad') else 64,frames=5 if mode=='age' or mode.startswith('move') else 4 if mode in ('quad','orbit') else 1,interval=4 if mode=='age' else 8 if mode=='orbit' else 1,quality=int(mode[-1]) if 'quality' in mode else 4,moveAt=65,half=True,maxDistance=5 if mode=='distance5' else 50)
 req=dict(outputDirectory=str(r/cfg['label']),fixture='S5MemorySSR',scene='S5QualityRuntime',camera='S5QualityCamera',requestRepaint=True,width=320,height=180,warmupFrames=cfg['warmup'],frameCount=cfg['frames'],frameInterval=cfg['interval'],timeoutSeconds=120,includeConfidence=False,buffers=['SSRMeta','SSRRayHit','SSR','SSRResolved','SSRTemporal','DisplayColor','Depth','GBufferA','GBufferB','GBufferC'],roi=dict(x=0,y=0,width=320,height=180))
 (r/'behavior-selection.json').write_text(json.dumps(cfg));(r/'capture-request.json').write_text(json.dumps(req));print('Starting',mode,flush=True)
 try:
  call('S5BehaviorControl.Start');t=time.monotonic()
  while True:
   x=call('S5BehaviorControl.Status')
   if x['finished']:break
   assert time.monotonic()-t<140,x
   time.sleep(1)
  call('S5BehaviorControl.Finish');print(mode,json.dumps(x),flush=True);assert x['outstanding']==0 and x['status']=='Completed',x
 except BaseException:
  try:
   x=call('S5BehaviorControl.Cancel');t=time.monotonic()
   while not x['finished']:
    assert time.monotonic()-t<45,x
    time.sleep(1);x=call('S5BehaviorControl.Status')
   assert x['outstanding']==0,x
   call('S5BehaviorControl.Cleanup')
  except BaseException as cleanup_error:print('Cleanup failed; keep owned producer identity and inspect:',repr(cleanup_error),flush=True)
  raise
