from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
r=Path(__file__).parent
out={}
def load(label):
 d=r/('behavior-'+label);j=json.loads((d/'capture.json').read_text());o={};hashes={}
 for b in j['buffers']:
  p=d/b['file'];raw=p.read_bytes();assert len(raw)==b['bytes'];fmt=b['format'];dt=np.float16 if fmt=='R16G16B16A16_SFloat' else np.float32 if 'SFloat' in fmt else np.uint8
  a=np.frombuffer(raw,dt).reshape(b['height'],b['width'],-1).astype(float);assert np.isfinite(a).all();o[b['captureIndex'],b['semantic']]=a;hashes[b['file']]=hashlib.sha256(raw).hexdigest();assert b['retired'] and b['readbackTerminal'] and b['submitted']
 assert j['status']=='Completed' and j['outstanding']==0
 out[label]={'metadata':j,'rawSHA256':hashes}
 return j,o

def world(f,d):
 h,w=d.shape;yy,xx=np.mgrid[:h,:w];p=np.stack(((xx+.5)/w*2-1,(yy+.5)/h*2-1,d,np.ones_like(d)),-1);m=f['inverseJitteredViewProjection'];m=np.array([[m[f'e{x}{y}'] for y in range(4)] for x in range(4)]);v=p@m.T;return v[:,:,:3]/v[:,:,3,None]
def image(a):
 x=np.maximum(a[:,:,:3][::-1],0);s=np.where(x<=.0031308,12.92*x,1.055*np.power(x,1/2.4)-.055);return Image.fromarray(np.uint8(np.clip(s,0,1)*255)).resize((640,360))
def strip(label,j,o):
 canvas=Image.new('RGB',(640*len(j['frames']),390),'#202020');draw=ImageDraw.Draw(canvas)
 for n,f in enumerate(j['frames']):
  i=f['captureIndex'];canvas.paste(image(o[i,'DisplayColor']),(n*640,30));draw.text((n*640+8,8),f'{label} captureIndex {i} / frame {f["frame"]}',fill='white')
 canvas.save(r/('behavior-'+label+'-presented.png'))

canvas=Image.new('RGB',(4*640,750),'#202020');draw=ImageDraw.Draw(canvas)
for q in range(4):
 label='rough-quality'+str(q);j,o=load(label);f=j['frames'][0];i=f['captureIndex'];canvas.paste(image(o[i,'DisplayColor']),(q*640,30));canvas.paste(image(o[i,'SSR']*4),(q*640,390));draw.text((q*640+8,8),f'{["Low","Medium","High","Ultra"][q]} / final normal frame',fill='white');draw.text((q*640+8,373),'SSR radiance x4, display sRGB (diagnostic gain)',fill='white');snap=json.loads((r/('behavior-'+label+'-behavior.json')).read_text());out[label]['settings']=snap['settings']
canvas.save(r/'rough-quality-grid.png');(r/'rough-quality-analysis.json').write_text(json.dumps(out,indent=2));print('rough grid generated')
