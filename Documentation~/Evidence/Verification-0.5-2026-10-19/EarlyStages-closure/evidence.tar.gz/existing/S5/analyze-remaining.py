from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
r=Path(__file__).parent
out={}
def load(label):
 d=r/('behavior-'+label);j=json.loads((d/'capture.json').read_text());o={};hashes={}
 for b in j['buffers']:
  p=d/b['file'];raw=p.read_bytes();assert len(raw)==b['bytes'];fmt=b['format'];dt=np.float16 if fmt=='R16G16B16A16_SFloat' else np.float32 if 'SFloat' in fmt else np.uint8
  a=np.frombuffer(raw,dt).reshape(b['height'],b['width'],-1).astype(float);assert np.isfinite(a).all();o[b['captureIndex'],b['semantic']]=a;hashes[b['file']]=hashlib.sha256(raw).hexdigest();assert b['retired'] and b['readbackTerminal'] and b['submitted']
 assert j['status']=='Completed' and j['outstanding']==0
 out[label]={'metadata':j,'rawSHA256':hashes}
 return j,o

def world(f,d):
 h,w=d.shape;yy,xx=np.mgrid[:h,:w];p=np.stack(((xx+.5)/w*2-1,(yy+.5)/h*2-1,d,np.ones_like(d)),-1);m=f['inverseJitteredViewProjection'];m=np.array([[m[f'e{x}{y}'] for y in range(4)] for x in range(4)]);v=p@m.T;return v[:,:,:3]/v[:,:,3,None]
def image(a):
 x=np.maximum(a[:,:,:3][::-1],0);s=np.where(x<=.0031308,12.92*x,1.055*np.power(x,1/2.4)-.055);return Image.fromarray(np.uint8(np.clip(s,0,1)*255)).resize((640,360))
def strip(label,j,o):
 canvas=Image.new('RGB',(640*len(j['frames']),390),'#202020');draw=ImageDraw.Draw(canvas)
 for n,f in enumerate(j['frames']):
  i=f['captureIndex'];canvas.paste(image(o[i,'DisplayColor']),(n*640,30));draw.text((n*640+8,8),f'{label} captureIndex {i} / frame {f["frame"]}',fill='white')
 canvas.save(r/('behavior-'+label+'-presented.png'))

quality=[];orbit=[];confidence=[]
for label in ['orbit','quality0','quality1','quality2','quality3','distance50','distance5']:
 j,o=load(label);strip(label,j,o)
 snap=json.loads((r/('behavior-'+label+'-behavior.json')).read_text());out[label]['resolvedSettings']=snap['settings'];out[label]['poses']=[{'frame':f['frame'],'position':f['position'],'rotation':f['rotation']} for f in j['frames']]
 if label.startswith('quality'):
  b=next(b for b in j['buffers'] if b['semantic']=='SSRRayHit');v=o[65,'SSR'];quality.append({'label':label,'settings':snap['settings'],'traceSize':[b['width'],b['height']],'frame':j['frames'][0]['frame'],'phase':j['frames'][0]['frame']%256,'ssrMaxRGB':float(v[:,:,:3].max()),'ssrMeanRGB':float(v[:,:,:3].mean()),'graph':list((r/('behavior-'+label)).glob('compiled-graph*'))[0].read_text()})
 if label.startswith('distance'):
  f=j['frames'][0];i=f['captureIndex'];d=o[i,'Depth'][:,:,0];surf=world(f,d);ray=np.repeat(np.repeat(o[i,'SSRRayHit'],2,axis=0),2,axis=1);yy,xx=np.mgrid[:180,:320];uvz=ray[:,:,:3];hp=np.concatenate((uvz[:,:,:2]*2-1,uvz[:,:,2:3],np.ones((180,320,1))),-1);m=f['inverseJitteredViewProjection'];m=np.array([[m[f'e{x}{y}'] for y in range(4)] for x in range(4)]);h=hp@m.T;h=h[:,:,:3]/h[:,:,3,None];delta=h-surf;dist=np.linalg.norm(delta,axis=-1);L=delta/np.maximum(dist[:,:,None],1e-20);norm=o[i,'GBufferB'][:,:,:3]/255*2-1;norm/=np.maximum(np.linalg.norm(norm,axis=-1,keepdims=True),1e-20);hi=np.clip((uvz[:,:,:2]*[320,180]).astype(int),[0,0],[319,179]);hitN=norm[hi[:,:,1],hi[:,:,0]];facing=np.clip(-np.sum(hitN*L,axis=-1)*4,0,1);edge=np.clip(np.minimum(np.min(uvz[:,:,:2],axis=-1),np.min(1-uvz[:,:,:2],axis=-1))/.05,0,1);maxD=snap['settings']['maxDistance'];df=np.clip((maxD-dist)/(.1*maxD),0,1);flags=o[i,'GBufferC'][:,:,0].astype(int)>>4;mirror=(o[i,'GBufferA'][:,:,2]/255<.05)&((flags&4)!=0)&((flags&2)==0)&(d>1e-6);positive=mirror&(ray[:,:,3]>0)&(np.sum(norm*L,axis=-1)>0)&(dist>1e-4);expected=np.where(positive,edge*facing*df,0);actual=o[i,'SSRResolved'][:,:,3];err=np.abs(actual-expected)[mirror];near=positive&(dist>.9*maxD)&(dist<maxD)&(facing>.95);back=positive&(facing==0);edgezone=positive&(edge>0)&(edge<1)&(facing>.95)&(df==1)
  row={'label':label,'mirrorPixels':int(mirror.sum()),'maxError':float(err.max()),'meanError':float(err.mean()),'positiveHits':int(positive.sum()),'nearMaxPixels':int(near.sum()),'nearConfidenceRange': [float(actual[near].min()),float(actual[near].max())] if near.any() else [],'backfacePixels':int(back.sum()),'backfaceAlphaMax':float(actual[back].max()) if back.any() else None,'edgeFadePixels':int(edgezone.sum()),'hitDistanceRange': [float(dist[positive].min()),float(dist[positive].max())]};confidence.append(row)
assert [x['traceSize'] for x in quality]==[[160,90],[160,90],[320,180],[320,180]]
assert all(x['phase']==65 for x in quality)
# Metadata and source formats establish genuine normal-frame collection; numeric comparison stays distinct from visual acceptance.
(r/'behavior-remaining-analysis.json').write_text(json.dumps({'captures':out,'qualities':quality,'confidence':confidence},indent=2));print(json.dumps({'qualities':[{k:v for k,v in x.items() if k!='graph'} for x in quality],'confidence':confidence},indent=2))
