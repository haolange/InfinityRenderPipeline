from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image,ImageDraw
r=Path(__file__).parent
out={}
def load(label):
 d=r/('behavior-'+label);j=json.loads((d/'capture.json').read_text());o={};hashes={}
 for b in j['buffers']:
  p=d/b['file'];raw=p.read_bytes();assert len(raw)==b['bytes'];fmt=b['format'];dt=np.float16 if fmt=='R16G16B16A16_SFloat' else np.float32 if 'SFloat' in fmt else np.uint8
  a=np.frombuffer(raw,dt).reshape(b['height'],b['width'],-1).astype(float);assert np.isfinite(a).all();o[b['captureIndex'],b['semantic']]=a;hashes[b['file']]=hashlib.sha256(raw).hexdigest();assert b['retired'] and b['readbackTerminal'] and b['submitted']
 assert j['status']=='Completed' and j['outstanding']==0
 out[label]={'metadata':j,'rawSHA256':hashes}
 return j,o

def world(f,d):
 h,w=d.shape;yy,xx=np.mgrid[:h,:w];p=np.stack(((xx+.5)/w*2-1,(yy+.5)/h*2-1,d,np.ones_like(d)),-1);m=f['inverseJitteredViewProjection'];m=np.array([[m[f'e{x}{y}'] for y in range(4)] for x in range(4)]);v=p@m.T;return v[:,:,:3]/v[:,:,3,None]
def image(a):
 x=np.maximum(a[:,:,:3][::-1],0);s=np.where(x<=.0031308,12.92*x,1.055*np.power(x,1/2.4)-.055);return Image.fromarray(np.uint8(np.clip(s,0,1)*255)).resize((640,360))
def strip(label,j,o):
 canvas=Image.new('RGB',(640*len(j['frames']),390),'#202020');draw=ImageDraw.Draw(canvas)
 for n,f in enumerate(j['frames']):
  i=f['captureIndex'];canvas.paste(image(o[i,'DisplayColor']),(n*640,30));draw.text((n*640+8,8),f'{label} captureIndex {i} / frame {f["frame"]}',fill='white')
 canvas.save(r/('behavior-'+label+'-presented.png'))
j,o=load('age');rows=[]
for f in j['frames']:
 i=f['captureIndex'];roi=(slice(16,32),slice(40,72));age=o[i,'SSRMeta'][roi][:,:,3];g=o[i,'GBufferA'][roi];flags=o[i,'GBufferC'][roi][:,:,0].astype(int)>>4;w=world(f,o[i,'Depth'][:,:,0])[roi];assert np.all(np.abs(w[:,:,1])<.03);assert np.all(g[:,:,2]/255<.05);assert np.all(((flags&4)!=0)&((flags&2)==0));assert np.all(age==i)
 rows.append({'captureIndex':i,'frame':f['frame'],'roi':[40,16,32,16],'pixels':int(age.size),'ageMin':float(age.min()),'ageMax':float(age.max()),'worldMin':w.min(axis=(0,1)).tolist(),'worldMax':w.max(axis=(0,1)).tolist()})
out['age']['fixedPhysicalFloorROI']=rows
j,o=load('quad');rows=[];order=[(0,0),(1,1),(1,0),(0,1)]
for f in j['frames']:
 i=f['captureIndex'];g=o[i,'GBufferA'][:,:,2]/255;flags=o[i,'GBufferC'][:,:,0].astype(int)>>4;valid=(o[i,'Depth'][:,:,0]>1e-6)&((flags&4)!=0)&((flags&2)==0)&(g<=.5);actual=o[i,'SSRRayHit'][:,:,3]!=0;counts=[int(np.sum(valid[y::2,x::2]!=actual)) for x,y in order];phase=f['frame']&3;assert counts[phase]==0 and all(v>0 for k,v in enumerate(counts) if k!=phase)
 rows.append({'frame':f['frame'],'phase':phase,'sourceOffset':list(order[phase]),'mismatchByOrder':counts,'nonZeroRayRecords':int(actual.sum())})
out['quad']['independentEligibilityResponse']=rows
j,o=load('move');strip('move-invalid-static',j,o);out['move']['verdict']='Invalid motion harness: MeshComponent was Static; no geometric disocclusion was produced. Not a product pass/failure.'
j,o=load('move-dynamic');base=j['frames'][0];a=world(base,o[65,'Depth'][:,:,0]);old=(a[:,:,0]>-1.8)&(a[:,:,0]<-.2)&(a[:,:,1]>.15)&(a[:,:,1]<1.85)&(a[:,:,2]>2.98)&(a[:,:,2]<5.02);rows=[]
for f in j['frames']:
 i=f['captureIndex'];b=world(f,o[i,'Depth'][:,:,0]);mask=old&(np.abs(b[:,:,1])<.03)&(o[i,'Depth'][:,:,0]<o[65,'Depth'][:,:,0]*.97);age=o[i,'SSRMeta'][:,:,3];vals,counts=np.unique(age[mask],return_counts=True);control=age[16:32,40:72];assert not f['historyReset'];assert np.all(control==64)
 if i==67:assert mask.sum()>600 and np.all(age[mask]==1)
 rows.append({'captureIndex':i,'frame':f['frame'],'disoccludedPhysicalFloor':int(mask.sum()),'ages':dict(zip([str(v) for v in vals],[int(v) for v in counts])),'controlAgeMin':float(control.min()),'controlAgeMax':float(control.max()),'cameraHistoryReset':f['historyReset']})
out['move-dynamic']['independentWorldDepthDisocclusion']=rows;out['move-dynamic']['timing']='Transform edited at begin probeIndex65 / captureIndex66; mesh proxy collection already occurred. GPU geometry first changes captureIndex67; check actual depth, not intent counter.'
strip('move-dynamic',j,o)
(r/'behavior-age-quad-move-analysis.json').write_text(json.dumps(out,indent=2));print(json.dumps({'age':out['age']['fixedPhysicalFloorROI'],'quad':out['quad']['independentEligibilityResponse'],'move':rows},indent=2))
