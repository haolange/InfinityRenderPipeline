from pathlib import Path
import subprocess,json,sys
r=Path(__file__).parent
file,entry,label=sys.argv[1:4];args=json.loads(sys.argv[4]) if len(sys.argv)>4 else []
p=subprocess.run(['/Users/gushihao/.unity/bin/unity','command','run_script','--project-path','/Volumes/DataDisk/Projects/Unity/InfinityExample','--caller','plugin','--skill','unity-cli','--format','json','--file',str(r/file),'--entry',entry,'--args',json.dumps(args)],capture_output=True,text=True)
(r/(label+'.json')).write_text(p.stdout)
j=json.loads(p.stdout);assert p.returncode==0 and j.get('data',{}).get('result',{}).get('success'),p.stdout
v=j['data']['result'];q=v.get('result');print(json.dumps({'success':v['success'],'pid':q.get('pid'),'moves':len(q.get('moves',[])),'fixtures':len(q.get('fixtures',[])),'defaultComponents':len(q.get('defaultProfile',{}).get('components',[]))} if isinstance(q,dict) and ('moves'in q or 'fixtures'in q) else v,ensure_ascii=False))
