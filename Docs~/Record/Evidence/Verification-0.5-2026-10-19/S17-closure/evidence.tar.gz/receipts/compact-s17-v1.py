from pathlib import Path
import tarfile,json,hashlib,io,zlib
import numpy as np
repo=Path('/Volumes/DataDisk/Projects/Unity/InfinityExample/Packages/com.infinity.render-pipeline');project=repo.parents[1];r=project/'intermediate/verification-0.5/20261020-run02/S17';out=repo/'Documentation~/Evidence/Verification-0.5-2026-10-19/S17-closure';out.mkdir(exist_ok=True);baseline=project/'ImageBaselines/Metal/Verification_0_5_20261020_run02';sha=lambda b:hashlib.sha256(b).hexdigest();members=[];raws=[];retired=[];seen=set()
s16=repo/'Documentation~/Evidence/Verification-0.5-2026-10-19/S16-closure/evidence.tar.gz';s16sha=sha(s16.read_bytes())
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 def add(n,b,source):
  assert n not in seen and not Path(n).is_absolute() and '..' not in Path(n).parts;seen.add(n);info=tarfile.TarInfo(n);info.size=len(b);info.mtime=0;t.addfile(info,io.BytesIO(b));members.append({'member':n,'bytes':len(b),'sha256':sha(b),'source':source})
 for p in sorted(r.rglob('*')):
  if not p.is_file() or p.name.startswith('._'):continue
  rel=str(p.relative_to(r));b=p.read_bytes()
  if p.name.startswith('DisplayColor') and p.suffix=='.bin':
   case=p.parent.name;meta=json.loads((baseline/(case+'.json')).read_text());base=(baseline/meta['file']).read_bytes();assert len(base)==len(b);row={'path':rel,'bytes':len(b),'sha256':sha(b),'baselineMember':'baseline/'+meta['file'],'baselineSha256':sha(base),'sourceArchive':str(s16.relative_to(repo)),'sourceArchiveSha256':s16sha}
   if b==base:row['encoding']='reference'
   else:
    diff=np.bitwise_xor(np.frombuffer(base,dtype=np.uint8),np.frombuffer(b,dtype=np.uint8)).tobytes();payload=zlib.compress(diff,9);n='raw-deltas/'+rel+'.xor-zlib';add(n,payload,str(p));row.update(encoding='xor-zlib',deltaMember=n);assert bytes(np.bitwise_xor(np.frombuffer(zlib.decompress(payload),dtype=np.uint8),np.frombuffer(base,dtype=np.uint8)))==b
   raws.append(row)
  elif p.name=='reload-checkpoint.json':
   j=json.loads(b);kept=[v for v in j['leaves'] if str(v.get('result','')).startswith('Skipped') and v.get('xml')];capsule={'sourceSha256':sha(b),'runGuid':j['runGuid'],'pid':j['pid'],'sourceLeafCount':len(j['leaves']),'leaves':kept,'note':'Exact original nonempty Skipped objects; native and callback results retained separately.'};add('receipts/'+rel+'.actual-skips.json',json.dumps(capsule,indent=2).encode(),str(p))
  elif p.name.endswith('.tar.gz'):
   retired.append({'path':rel,'bytes':len(b),'sha256':sha(b),'reason':'Consumed replay/frozen source container; expanded source identities and final source snapshots retained.'})
  else:add('receipts/'+rel,b,str(p))
 add('raw-locations.json',json.dumps(raws,indent=2).encode(),'lossless reconstruction index')
 for n in ['Editor/Tools/Validation/CreateLocalLightsValidationScene.cs','Editor/Tools/Validation/CreateTranslucentValidationScene.cs','Tests/Editor/PipelineSeamTests.cs','Tests/Editor/ValidationFixtureSaveTests.cs']:
  add('candidate-source/'+n,(repo/n).read_bytes(),str(repo/n))
 for n in ['Assets/InfinityRenderPipelineGlobalSettings.asset','ProjectSettings/EditorSettings.asset','ProjectSettings/ProjectSettings.asset','ProjectSettings/TimeManager.asset']:
  p=r.parent/'preimage'/n;add('original-input/'+n,p.read_bytes(),str(p))
 for n in ['input-manifest.json','outer-status-before.bin','asset-delta-before-S1.json','editor-log-mark.json']:
  p=r.parent/n;add('initial-audit/'+n,p.read_bytes(),str(p))
 for n in ['LocalLights','Translucent']:
  p=project/f'Assets/InfinityRPVerification_0_5_20261020_run02/S16/Fixtures/Validation_{n}_Volume.asset';add('repaired-fixture/'+p.name,p.read_bytes(),str(p))
manifest={'archiveBytes':(out/'evidence.tar.gz').stat().st_size,'archiveSha256':sha((out/'evidence.tar.gz').read_bytes()),'members':members,'rawReconstructionCount':len(raws),'consumedContainers':retired,'baselineSourceArchiveSha256':s16sha};(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(out/'evidence.tar.gz') as t:
 assert len(t.getmembers())==len(members)
 for m,v in zip(t.getmembers(),members):assert m.isfile() and m.name==v['member'] and sha(t.extractfile(m).read())==v['sha256']
print(json.dumps({'members':len(members),'archiveBytes':manifest['archiveBytes'],'archiveSha256':manifest['archiveSha256'],'raws':len(raws)}))
