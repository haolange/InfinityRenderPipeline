from pathlib import Path
import tarfile,json,hashlib,io,re
repo=Path('/Volumes/DataDisk/Projects/Unity/InfinityExample/Packages/com.infinity.render-pipeline');r=repo.parents[1]/'intermediate/verification-0.5/20261020-run02';out=repo/'Documentation~/Evidence/Verification-0.5-2026-10-19/EarlyStages-closure';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[];excluded=[];seen=set();suffixes={'.json','.xml','.cs','.py','.txt','.md','.patch','.png','.jpg','.jpeg','.compute','.hlsl','.meta','.asset'}
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=9) as dest:
 def add(name,data,origin,original=None):
  assert name not in seen and not Path(name).is_absolute() and '..' not in Path(name).parts;seen.add(name)
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;dest.addfile(info,io.BytesIO(data));rows.append({'member':name,'bytes':len(data),'sha256':sha(data),'origin':origin,**({'sourceSha256':original} if original else {})})
 def collect(name,data,origin):
  if name.endswith('reload-checkpoint.json'):
   j=json.loads(data);leaves=j.get('leaves',[]);kept=[v for v in leaves if str(v.get('result','')).startswith('Skipped') and v.get('xml')];capsule={'sourceSha256':sha(data),'runGuid':j.get('runGuid'),'pid':j.get('pid'),'sourceLeafCount':len(leaves),'note':'Exact nonempty checkpoint Skipped objects; native and callback XML remain separately retained. Not a manufactured full framework result.','leaves':kept};add(name+'.actual-skips.json',json.dumps(capsule,ensure_ascii=False,indent=2).encode(),origin,sha(data))
  else:add(name,data,origin)
 early=repo/'Documentation~/Evidence/Verification-0.5-2026-10-19'
 for f in sorted(early.rglob('*')):
  rel=str(f.relative_to(early))
  if f.is_file() and not f.name.startswith('._') and re.match(r'S[1-9](?:[-/.]|$)',rel):add('existing/'+rel,f.read_bytes(),str(f))
 for stage in ['S6','S7']:
  for f in sorted((r/stage).rglob('*')):
   if not f.is_file() or f.name.startswith('._'):continue
   rel=str(f.relative_to(r));size=f.stat().st_size
   if f.suffix in suffixes:collect('scratch/'+rel,f.read_bytes(),str(f))
   elif f.name.endswith('.tar.gz'):
    with tarfile.open(f) as src:
     for m in src.getmembers():
      if m.isfile() and not Path(m.name).name.startswith('._') and Path(m.name).suffix in suffixes:
       assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
       collect('nested/'+rel+'/'+m.name,src.extractfile(m).read(),str(f)+'::'+m.name)
    excluded.append({'path':str(f),'bytes':size,'sha256':sha(f.read_bytes()),'reason':'Container retired after selected source/test/capture metadata extraction; raw captures not promoted wholesale.'})
   else:excluded.append({'path':str(f),'bytes':size,'sha256':sha(f.read_bytes()),'reason':'Consumed diagnostic raw/log/binary; key image/numeric/test/source receipts retained separately.'})
manifest={'scope':'S1-S9 evidence previously written locally but not tracked; this delivery promotes explicitly indexed receipts. S6/S7 consumed raw/logs retired after independent metadata/test/frame review.','members':rows,'retiredInputs':excluded,'archiveBytes':(out/'evidence.tar.gz').stat().st_size,'archiveSha256':sha((out/'evidence.tar.gz').read_bytes())};(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
with tarfile.open(out/'evidence.tar.gz') as t:
 members=t.getmembers();assert len(members)==len(rows)
 for m,v in zip(members,rows):assert m.isfile() and m.name==v['member'] and sha(t.extractfile(m).read())==v['sha256']
print(json.dumps({'members':len(rows),'retiredInputs':len(excluded),'archiveBytes':manifest['archiveBytes'],'archiveSha256':manifest['archiveSha256']}))
