from pathlib import Path
import UnityPy,json,hashlib
from UnityPy.helpers.TypeTreeNode import TypeTreeNode
r=Path(__file__).parent;project=r.parents[3];base=r.parent;original=TypeTreeNode.parse_blob.__func__
def blob(cls,reader,version):
 if version>=23:
  reader.read_bytes(16);size=reader.read_int();start=reader.Position;assert reader.read_bytes(4)==b'mhtt';v=reader.read_int();assert v==23;node=original(cls,reader,v);assert reader.Position==start+size;return node
 return original(cls,reader,version)
TypeTreeNode.parse_blob=classmethod(blob)
def tree(p):return [{'pathID':o.path_id,'type':o.type.name,'data':o.read_typetree()} for o in UnityPy.load(str(p)).objects]
def differences(a,b,path=''):
 out=[]
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  for k in a.keys()|b.keys():out+=differences(a.get(k),b.get(k),path+'/'+str(k))
 elif isinstance(a,list):
  if len(a)!=len(b):out.append({'path':path+'/length','before':len(a),'after':len(b)})
  for i,(x,y) in enumerate(zip(a,b)):out+=differences(x,y,path+'/'+str(i))
 elif a!=b:out.append({'path':path,'before':a,'after':b})
 return out
j=json.loads((base/'input-manifest.json').read_text());expected={v['path']:v for v in j['files']};rows=[]
for n in j['backed_up']:
 old=base/'preimage'/n;assert old.is_file();a=old.read_bytes();assert hashlib.sha256(a).hexdigest()==expected[n]['sha256'];current=project/n;b=current.read_bytes();same=a==b;row={'path':n,'oldSha256':hashlib.sha256(a).hexdigest(),'currentSha256':hashlib.sha256(b).hexdigest(),'same':same}
 if not same and n.startswith('ProjectSettings/'):
  d=differences(tree(old),tree(current));row['nativeSemanticDifferences']=d;print(n,[(x['path'],x['before'],x['after']) for x in d])
 rows.append(row)
result={'declaredInputs':len(j['files']),'declaredBackups':len(j['backed_up']),'allDeclaredBackupsPresentAndMatchManifest':True,'notBackedUpByDesign':len(j['files'])-len(j['backed_up']),'sameBytes':sum(x['same'] for x in rows),'rows':rows,'policy':'No stale native asset wholesale restore. Four distinct original preimages retained in permanent source audit; all other duplicates retire only after current-byte identity proof.'};(r/'final-preimage-audit-v1.json').write_text(json.dumps(result,indent=2))
